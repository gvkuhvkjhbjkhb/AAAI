# Round 7 Decisive AAAI Report

This report merges prior Round 6 controls with newly completed Round 7 decisive controls.

## Grouped Results

| method | n | last test | last test 95% CI | train AUC | best train | stability gap |
|---|---:|---:|---:|---:|---:|---:|
| adaptive_0.0002_late045 | 8 | 0.2435 | [0.2010, 0.2858] | 0.1900 | 0.4442 | 0.2007 |
| adaptive_0.0002_late060 | 8 | 0.2432 | [0.2013, 0.2849] | 0.1899 | 0.4433 | 0.2001 |
| adaptive_0.0003_late045 | 8 | 0.2375 | [0.1640, 0.3121] | 0.1806 | 0.4180 | 0.1805 |
| baseline | 8 | 0.1847 | [0.1276, 0.2549] | 0.1528 | 0.2769 | 0.0922 |
| diagnosis_only | 8 | 0.2258 | [0.1827, 0.2796] | 0.1827 | 0.3532 | 0.1274 |
| random_type_0.0002 | 8 | 0.3048 | [0.2327, 0.3747] | 0.2308 | 0.5270 | 0.2222 |
| random_type_0.0003_late045 | 8 | 0.2192 | [0.1806, 0.2619] | 0.1759 | 0.3736 | 0.1544 |
| random_type_0.0003_late060 | 8 | 0.2154 | [0.1776, 0.2578] | 0.1756 | 0.3746 | 0.1591 |
| random_type_matched_0.0003_late045 | 8 | 0.2580 | [0.2171, 0.3090] | 0.2012 | 0.3935 | 0.1355 |
| semantic_gate_0.0003_late045 | 8 | 0.2382 | [0.2000, 0.2805] | 0.1900 | 0.3987 | 0.1605 |
| type_specific_0.0002 | 8 | 0.2514 | [0.2181, 0.2860] | 0.1981 | 0.3778 | 0.1264 |
| type_specific_0.0003 | 8 | 0.2755 | [0.2268, 0.3272] | 0.2072 | 0.4878 | 0.2123 |
| uniform_0.0002 | 8 | 0.2170 | [0.1572, 0.2788] | 0.1644 | 0.3436 | 0.1266 |
| uniform_0.0003 | 8 | 0.2892 | [0.2419, 0.3415] | 0.2092 | 0.5658 | 0.2767 |

## Paired Decision Comparisons

| comparison | metric | n | mean delta | 95% CI | shared seeds |
|---|---|---:|---:|---:|---|
| semantic_gate_0.0003_late045 - random_type_matched_0.0003_late045 | last_test_return | 8 | -0.0199 | [-0.0716, 0.0348] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_matched_0.0003_late045 | train_auc | 8 | -0.0111 | [-0.0455, 0.0198] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_matched_0.0003_late045 | best_train_return | 8 | 0.0052 | [-0.1301, 0.1372] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_matched_0.0003_late045 | stability_gap | 8 | 0.0251 | [-0.0646, 0.1110] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_0.0003_late045 | last_test_return | 8 | 0.0190 | [-0.0512, 0.0808] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_0.0003_late045 | train_auc | 8 | 0.0141 | [-0.0339, 0.0537] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_0.0003_late045 | best_train_return | 8 | 0.0251 | [-0.1174, 0.1663] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - random_type_0.0003_late045 | stability_gap | 8 | 0.0061 | [-0.0880, 0.1045] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - adaptive_0.0003_late045 | last_test_return | 8 | 0.0007 | [-0.0638, 0.0662] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - adaptive_0.0003_late045 | train_auc | 8 | 0.0094 | [-0.0304, 0.0481] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - adaptive_0.0003_late045 | best_train_return | 8 | -0.0193 | [-0.1750, 0.1277] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - adaptive_0.0003_late045 | stability_gap | 8 | -0.0199 | [-0.1198, 0.0659] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - uniform_0.0003 | last_test_return | 8 | -0.0510 | [-0.1246, 0.0220] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - uniform_0.0003 | train_auc | 8 | -0.0191 | [-0.0602, 0.0176] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - uniform_0.0003 | best_train_return | 8 | -0.1671 | [-0.3135, -0.0096] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - uniform_0.0003 | stability_gap | 8 | -0.1161 | [-0.1933, -0.0287] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - baseline | last_test_return | 8 | 0.0535 | [0.0045, 0.0898] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - baseline | train_auc | 8 | 0.0372 | [0.0070, 0.0631] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - baseline | best_train_return | 8 | 0.1218 | [0.0440, 0.1909] | 1,2,3,4,5,6,7,8 |
| semantic_gate_0.0003_late045 - baseline | stability_gap | 8 | 0.0683 | [0.0297, 0.1150] | 1,2,3,4,5,6,7,8 |
| random_type_matched_0.0003_late045 - adaptive_0.0003_late045 | last_test_return | 8 | 0.0205 | [-0.0507, 0.0935] | 1,2,3,4,5,6,7,8 |
| random_type_matched_0.0003_late045 - adaptive_0.0003_late045 | train_auc | 8 | 0.0206 | [-0.0265, 0.0673] | 1,2,3,4,5,6,7,8 |
| random_type_matched_0.0003_late045 - adaptive_0.0003_late045 | best_train_return | 8 | -0.0245 | [-0.1961, 0.1452] | 1,2,3,4,5,6,7,8 |
| random_type_matched_0.0003_late045 - adaptive_0.0003_late045 | stability_gap | 8 | -0.0450 | [-0.1508, 0.0564] | 1,2,3,4,5,6,7,8 |

## Submission Rule

Use the strong semantic AAAI claim only if semantic_gate beats baseline, uniform, adaptive, and matched random-type controls on paired final return or train AUC. If matched random remains tied or stronger, use the safer calibrated failure-triggered adaptive-shaping framing and present semantic diagnosis as interpretability plus gating.
