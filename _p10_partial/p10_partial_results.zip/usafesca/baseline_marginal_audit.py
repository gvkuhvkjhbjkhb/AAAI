"""
baseline_marginal_audit.py -- 0-GPU marginal-value audit of ActionSafe against
four *action-aware* comparator gates (supplement Sec. A, second table).

OldGate is the diagnosed object, not a competitive baseline: it never reads the
proposed profile, so beating it says nothing about whether reading the profile
was worth it.  The comparators below all read a*, and differ only in what they
extract from it.  Definitions are exactly those stated in the supplement:

  PerRoleOnly   permit iff min_i m_i >= -eps_R                      ((C2) alone)
  ParetoFilter  permit iff u_i(a*) >= rbar_i for all i
  Egalitarian   permit iff a* maximizes min_i (u_i(a) - rbar_i) over all
                profiles AND that margin clears -eps_R                (minimax)
  ConstrainedOpt permit iff a* == argmax_{a : u_i(a) >= rho for all i} u_T(a)

with m_i = u_i(a*) - rbar_i.

Ground truth is the same threshold-free labelling used by random_games_audit.py
(a role strictly below its reference => harmful), so nothing here is defined in
terms of the certificate's own margins.

For every disagreement we attribute ActionSafe's catch to the responsible
condition(s), which is the quantity the paper actually claims: *which* of
(C1)-(C4) is doing the work, and on which distribution.

Run:  python baseline_marginal_audit.py          (~20 s, CPU only)
"""
from __future__ import annotations

import numpy as np

from certificate import (EPS_R, EPS_T, LAMBDA, PROFILES, RHO, actionsafe,
                         reference_uniform, target_profile, team_payoff)
from random_games_audit import (ground_truth_label, sample_adversarial_game,
                                sample_integer_game, sample_uniform_game)

N_GAMES = 8000
SEED = 20260726


# --------------------------------------------------------------------------
# comparator gates (all read the proposed profile a*)
# --------------------------------------------------------------------------
def _margins(U, rbar, lam=LAMBDA):
    a1, a2 = target_profile(U, lam)
    u = np.array([U[a1, a2, 0], U[a1, a2, 1]])
    return (a1, a2), u, u - rbar


def per_role_only(U, rbar, eps_R=EPS_R):
    _, _, m = _margins(U, rbar)
    return bool(np.min(m) >= -eps_R)


def pareto_filter(U, rbar):
    _, u, _ = _margins(U, rbar)
    return bool(np.all(u >= rbar))


def egalitarian(U, rbar, eps_R=EPS_R):
    astar, _, m = _margins(U, rbar)
    best = max(min(U[a1, a2, i] - rbar[i] for i in (0, 1)) for (a1, a2) in PROFILES)
    return bool(np.min(m) >= best - 1e-12 and np.min(m) >= -eps_R)


def constrained_opt(U, rbar, rho=RHO):
    astar, _, _ = _margins(U, rbar)
    feasible = [(a1, a2) for (a1, a2) in PROFILES
                if U[a1, a2, 0] >= rho and U[a1, a2, 1] >= rho]
    if not feasible:
        return False
    best = max(feasible, key=lambda a: team_payoff(U, a[0], a[1]))
    return bool(tuple(astar) == tuple(best))


BASELINES = {
    "PerRoleOnly (C2)": per_role_only,
    "ParetoFilter": pareto_filter,
    "Egalitarian": egalitarian,
    "ConstrainedOpt": constrained_opt,
}


# --------------------------------------------------------------------------
def run(sampler, n=N_GAMES, seed=SEED):
    rng = np.random.default_rng(seed)
    out = {name: dict(as_permit_base_veto=0, as_veto_base_permit=0,
                      of_which_harmful=0, caught_via={})
           for name in BASELINES}
    n_harmful = 0
    for _ in range(n):
        U = sampler(rng)
        rbar = reference_uniform(U)
        label, _ = ground_truth_label(U, rbar)
        n_harmful += int(label == "harmful")
        v = actionsafe(U, rbar)
        for name, fn in BASELINES.items():
            b = fn(U, rbar)
            if v.permit and not b:
                out[name]["as_permit_base_veto"] += 1
            elif (not v.permit) and b:
                out[name]["as_veto_base_permit"] += 1
                if label == "harmful":
                    out[name]["of_which_harmful"] += 1
                    key = ";".join(v.failed)
                    out[name]["caught_via"][key] = out[name]["caught_via"].get(key, 0) + 1
    return out, n_harmful


def _fmt_caught(d, top=3):
    if not d:
        return "---"
    items = sorted(d.items(), key=lambda kv: -kv[1])[:top]
    return "; ".join(f"{k}={v}" for k, v in items)


if __name__ == "__main__":
    samplers = {
        "uniform[0,1]": sample_uniform_game,
        "integer{0..5}": sample_integer_game,
        "adversarial(near-C2)": sample_adversarial_game,
    }
    print("=" * 92)
    print(f"MARGINAL VALUE of ActionSafe over action-aware baselines "
          f"(N={N_GAMES}/distribution, seed={SEED}, lambda={LAMBDA})")
    print("=" * 92)
    for dist, s in samplers.items():
        res, n_harm = run(s)
        print(f"\n### {dist}   (ground-truth harmful = {n_harm})")
        print(f"{'vs. baseline':<20}{'AS permit/':>12}{'AS veto/':>11}"
              f"{'of which':>10}   ActionSafe caught via")
        print(f"{'':<20}{'base veto':>12}{'base permit':>11}{'harmful':>10}")
        for name, r in res.items():
            tot = r["of_which_harmful"]
            c4 = sum(v for k, v in r["caught_via"].items() if "C4" in k)
            share = f"  [C4 involved in {c4}/{tot} = {c4/tot:.1%}]" if tot else ""
            print(f"{name:<20}{r['as_permit_base_veto']:>12}"
                  f"{r['as_veto_base_permit']:>11}{r['of_which_harmful']:>10}"
                  f"   {_fmt_caught(r['caught_via'])}{share}")
