#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from common import immutable_json, load_protocol, sha256_file
from utility_model import fit_from_p4


def main() -> None:
    ap = argparse.ArgumentParser(); ap.add_argument("--protocol", type=Path, required=True); ap.add_argument("--p4-root", type=Path, required=True); ap.add_argument("--out", type=Path, required=True); ap.add_argument("--profile", default="qwen_glm")
    args = ap.parse_args(); protocol = load_protocol(args.protocol.resolve()); model = fit_from_p4(protocol, args.p4_root.resolve(), args.profile)
    model["protocol_sha256"] = sha256_file(args.protocol.resolve()); immutable_json(args.out.resolve(), model); print(model["model_sha256"])


if __name__ == "__main__": main()
