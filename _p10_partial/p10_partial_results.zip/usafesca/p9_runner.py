"""p9_runner.py -- confirmatory 4x4 campaign (review blocker B2).

Why this campaign exists
------------------------
Every prior campaign uses 2x2 games, where the relation summary
q(a) = 1[a1 == a2] is *trivially* lossy (it collapses two off-diagonal
profiles).  A reviewer can therefore call the demonstration degenerate.
At |A| = 4 the same summary collapses TWELVE off-diagonal profiles --
Pareto improvements and role extractions alike -- into a single bit, so the
certificate-intervention mismatch is exercised where the action space is
genuinely non-trivial, while the certificate (C1)-(C4) transfers *unchanged*:
none of its four conditions mentions |A|.

Structure mirrors the P7 realization campaign exactly:
  P9D  development phase, its own registry: selects one role-binding
       presentation by a frozen rule and preflights 4x4 prompt parsing.
  P9   fresh-registry confirmatory phase.  Actual arms: NoAlign and the
       selected advisory.  ActionSafeFixed / OldGateFixed are DERIVED from
       the same common-random-number trajectories (no extra model calls).

Run (see scripts/run_all.sh):
  python code/p9_runner.py --protocol protocol/p9_4x4_frozen.json \
      --results-root results_smoke --phase p9d --backend synthetic
  python code/p9_runner.py ... --phase p9d --analyze
  # live: --backend vllm --workers 48; p9 is blocked until P9D_SELECTION.json
  # records selection_success=true.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib import request

import numpy as np

N = 4                                   # actions per role
LETTERS = "ABCD"
LAMBDA = 0.25                           # Eq.(1) inequity penalty (frozen)


# ----------------------------------------------------------------- utilities
def stable_seed(*parts: Any) -> int:
    h = hashlib.sha256("|".join(str(p) for p in parts).encode()).hexdigest()
    return int(h[:12], 16)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(p: Path) -> dict:
    return json.loads(p.read_text())


def dump(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, sort_keys=True))


# ------------------------------------------------------------------- matrices
@dataclass(frozen=True)
class Matrix:
    matrix_id: str
    family: str
    payoff: tuple  # payoff[i][j] = (u1, u2), i,j in 0..3

    def target(self) -> tuple[int, int]:
        best, bv = None, None
        for i in range(N):
            for j in range(N):
                a, b = self.payoff[i][j]
                v = (a + b) / 2 - LAMBDA * abs(a - b)
                if bv is None or v > bv + 1e-12:
                    best, bv = (i, j), v
        return best

    def is_pure_nash(self, i: int, j: int) -> bool:
        u1 = self.payoff[i][j][0]
        u2 = self.payoff[i][j][1]
        if any(self.payoff[r][j][0] > u1 + 1e-12 for r in range(N)):
            return False
        if any(self.payoff[i][c][1] > u2 + 1e-12 for c in range(N)):
            return False
        return True

    def audit(self) -> dict:
        return {"matrix_id": self.matrix_id, "analysis_family": self.family,
                "payoff_matrix": [[list(p) for p in row] for row in self.payoff]}


def _pair(rng, a, b, s=0.12):
    return (round(float(a + rng.uniform(-s, s)), 2), round(float(b + rng.uniform(-s, s)), 2))


def _blank(rng, lo=0.1, hi=1.2):
    return tuple(tuple((round(float(rng.uniform(lo, hi)), 2),
                        round(float(rng.uniform(lo, hi)), 2)) for _ in range(N)) for _ in range(N))


def _with(P, i, j, v):
    P = [list(r) for r in P]
    P[i][j] = v
    return tuple(tuple(r) for r in P)


def _make(family: str, rng: np.random.Generator) -> tuple:
    """Rejection-sample until the family's defining properties hold exactly."""
    for _ in range(500):
        ti, tj = int(rng.integers(N)), int(rng.integers(N))
        if ti == tj and family in ("anti_safe", "anti_tradeoff"):
            continue
        if family == "anti_safe":
            # low everywhere; one off-diagonal strict-NE target that Pareto-
            # improves on the whole diagonal basin, with small inequity.
            P = _blank(rng, 0.1, 1.3)
            P = _with(P, ti, tj, _pair(rng, 4.35, 4.05))
            m = Matrix("tmp", family, P)
            t = m.target()
            u = P[t[0]][t[1]]
            diag_best = max(max(P[k][k]) for k in range(N))
            if (t == (ti, tj) and ti != tj and m.is_pure_nash(*t)
                    and min(u) > diag_best + 1.5 and min(u) >= 0.25):
                return P
        elif family == "anti_tradeoff":
            # one off-diagonal strict-NE target that RAISES team-mean payoff
            # while driving role 1 to ~0 (< rho and < warm-up reference).
            P = _blank(rng, 0.05, 0.5)
            for k in range(N):
                P = _with(P, k, k, _pair(rng, 0.92, 0.92, 0.08))
            # make target role-1's best response in its column: alternatives < 0
            for r in range(N):
                if r != ti:
                    P = _with(P, r, tj, _pair(rng, -0.35, 0.25, 0.06))
            P = _with(P, ti, tj, _pair(rng, 0.02, 5.0, 0.04))
            m = Matrix("tmp", family, P)
            t = m.target()
            u = P[t[0]][t[1]]
            team_t = sum(u) / 2
            diag_team = max(sum(P[k][k]) / 2 for k in range(N))
            if (t == (ti, tj) and ti != tj and m.is_pure_nash(*t)
                    and u[0] < 0.25 and team_t > diag_team + 1.0):
                return P
        elif family == "coordination":
            # the best profile is ON the diagonal: the relation summary is
            # exactly right here, so every gate should agree (control family).
            P = _blank(rng, 0.1, 1.0)
            k = int(rng.integers(N))
            P = _with(P, k, k, _pair(rng, 4.25, 4.10))
            k2 = (k + 1 + int(rng.integers(N - 1))) % N
            P = _with(P, k2, k2, _pair(rng, 3.15, 3.05))
            m = Matrix("tmp", family, P)
            t = m.target()
            if t == (k, k) and m.is_pure_nash(*t):
                return P
        elif family == "mixed":
            # near-flat surface; targets are sometimes non-equilibria, which
            # is exactly the (C4)-binding regime.  No property forced.
            base = 2.15 + float(rng.uniform(-0.1, 0.1))
            return tuple(tuple((round(base + float(rng.uniform(-0.3, 0.3)), 2),
                                round(base + float(rng.uniform(-0.3, 0.3)), 2))
                               for _ in range(N)) for _ in range(N))
    raise RuntimeError(f"could not sample a valid {family} matrix")


def registry(seed: int, n_per_family, families) -> list[Matrix]:
    rng = np.random.default_rng(seed)
    out = []
    for fam in families:
        n = n_per_family[fam] if isinstance(n_per_family, dict) else n_per_family
        for i in range(1, n + 1):
            out.append(Matrix(f"p9_{fam}_{i:02d}", fam, _make(fam, rng)))
    return out


# ----------------------------------------------------------------- gates
def _boot_upper(x: np.ndarray, draws: int, conf: float, rng) -> float:
    idx = rng.integers(0, len(x), size=(draws, len(x)))
    return float(np.quantile(x[idx].mean(axis=1), conf))


def actionsafe_verdict(warmup: list[dict], m: Matrix, cfg: dict, seed: int) -> dict:
    """(C1)-(C4) against the 95% bootstrap-UPPER warm-up reference.
    Identical logic to the 2x2 deployment (action_safety.py); nothing here
    depends on |A| except the deviation scan and profile-coverage base."""
    rng = np.random.default_rng(seed)
    t = m.target()
    tu = np.asarray(m.payoff[t[0]][t[1]], float)
    R = np.asarray([s["rewards"] for s in warmup], float)
    draws, conf = int(cfg["bootstrap_samples"]), float(cfg["confidence"])
    up = [_boot_upper(R[:, r], draws, conf, rng) for r in range(2)]
    up_T = _boot_upper(R.mean(axis=1), draws, conf, rng)
    dev = [max(m.payoff[r][t[1]][0] for r in range(N)) - tu[0],
           max(m.payoff[t[0]][c][1] for c in range(N)) - tu[1]]
    profiles = {tuple(s["actions"]) for s in warmup}
    reasons = []
    if len(warmup) < cfg["min_total_observations"]:
        reasons.append("insufficient_total_observations")
    if len(profiles) / (N * N) < cfg["min_profile_coverage"]:
        reasons.append("insufficient_profile_coverage")
    if tu.mean() - up_T < -cfg["team_noninferiority_margin"]:
        reasons.append("C1_team_noninferiority")
    if min(tu[r] - up[r] for r in range(2)) < -cfg["role_noninferiority_margin"]:
        reasons.append("C2_role_noninferiority")
    if float(tu.min()) < cfg["minimum_role_target_reward"]:
        reasons.append("C3_role_floor")
    if max(dev) > cfg["max_unilateral_deviation_gain"] + 1e-9:
        reasons.append("C4_deviation_stability")
    return {"certificate": "action_aligned_feasibility_v1_4x4", "target": list(t),
            "target_rewards": tu.tolist(), "baseline_upper": up + [up_T],
            "deviation_gains": dev, "safety_pass": not reasons, "safety_reasons": reasons}


def oldgate_verdict(warmup: list[dict], cfg: dict, seed: int) -> dict:
    """Relation-level gate, verbatim from the 2x2 deployment: does the
    same-action relation beat the different-action relation?  At |A|=4 this
    reads ONE bit about 12 off-diagonal profiles."""
    same = [float(np.mean(s["rewards"])) for s in warmup if s["actions"][0] == s["actions"][1]]
    diff = [float(np.mean(s["rewards"])) for s in warmup if s["actions"][0] != s["actions"][1]]
    profiles = {tuple(s["actions"]) for s in warmup}
    reasons, upper = [], None
    if len(same) < cfg["min_same_observations"]:
        reasons.append("insufficient_same_observations")
    if len(diff) < cfg["min_different_observations"]:
        reasons.append("insufficient_different_observations")
    if len(profiles) / (N * N) < cfg["min_profile_coverage"]:
        reasons.append("insufficient_profile_coverage")
    if same and diff:
        rng = np.random.default_rng(seed)
        a, b = np.asarray(same), np.asarray(diff)
        d = int(cfg["bootstrap_samples"])
        boot = (b[rng.integers(0, len(b), (d, len(b)))].mean(1)
                - a[rng.integers(0, len(a), (d, len(a)))].mean(1))
        upper = float(np.quantile(boot, cfg["confidence"]))
        if upper >= -float(cfg["tau"]):
            reasons.append("coordination_not_certified")
    else:
        reasons.append("split_confidence_unavailable")
    return {"certificate": "relation_level_legacy", "split_upper": upper,
            "n_same": len(same), "n_different": len(diff),
            "safety_pass": not reasons, "safety_reasons": reasons}


# ----------------------------------------------------------------- prompting
def matrix_text(m: Matrix, role: int) -> str:
    head = "Other " + " | Other ".join(LETTERS)
    rows = []
    for own in range(N):
        cells = []
        for other in range(N):
            pr = m.payoff[own][other] if role == 0 else m.payoff[other][own]
            mine, theirs = (pr[0], pr[1]) if role == 0 else (pr[1], pr[0])
            cells.append(f"({mine:+.2f},{theirs:+.2f})")
        rows.append(f"Self {LETTERS[own]} " + " | ".join(cells))
    return head + "\n" + "\n".join(rows)


def prompt(m: Matrix, role: int, history: list, intervention: str, memory: int) -> list[dict]:
    t = m.target()
    assigned, partner = LETTERS[t[role]], LETTERS[t[1 - role]]
    hist = "none" if not history else "; ".join(
        f"you={LETTERS[s['actions'][role]]}, other={LETTERS[s['actions'][1 - role]]}"
        for s in history[-memory:])
    cue = ""
    if intervention == "RoleBoundConfirm":
        cue = (f"Role-bound plan: you are {'Row' if role == 0 else 'Column'}; commit to "
               f"{assigned}. The other player is assigned {partner}. Execute YOUR assigned action now.")
    elif intervention == "RoleBoundAcknowledge":
        cue = (f"Role-bound plan: you are {'Row' if role == 0 else 'Column'}; your assigned "
               f"action is {assigned}; the other player is assigned {partner}. Internally "
               f"verify the pair, then execute YOUR assigned action now.")
    ex = LETTERS[len(history) % N]
    sysmsg = (f"You are playing a simultaneous {N}-action matrix game. There is no default action: any of "
              f"{', '.join(LETTERS)} can be best -- decide from the payoff table. Reply with ONE line only, "
              f"in exactly this format: ACTION: <letter> (for example: ACTION: {ex}). "
              f"Output only that single line: no explanation, no payoffs, no other text.")
    return [{"role": "system", "content": sysmsg},
            {"role": "user", "content":
             f"You are {'Row' if role == 0 else 'Column'} in a simultaneous {N}-action game. "
             f"Entries are (your payoff, other payoff).\n{matrix_text(m, role)}\n"
             f"Recent: {hist}\n{cue}\nChoose your action now and reply with ACTION: <letter>."}]


ACTION_RE = re.compile(r"ACTION\s*:?\s*([ABCD])", re.I)
BARE_RE = re.compile(r"\b([ABCD])\b", re.I)


def parse_action(text: str) -> int:
    if not text or not text.strip():
        raise ValueError(f"empty response {text!r}")
    m = ACTION_RE.search(text) or BARE_RE.search(text)
    if m:
        return LETTERS.index(m.group(1).upper())
    s = text.strip().upper().rstrip(".")
    if s in LETTERS:
        return LETTERS.index(s)
    raise ValueError(f"unparseable response {text!r}")


# ----------------------------------------------------------------- backends
class Backend:
    def __init__(self, cfg: dict, sampling: dict, mode: str, max_retries: int = 2):
        self.cfg, self.sampling, self.mode, self.max_retries = cfg, sampling, mode, max_retries
        self.parse_retries = 0

    def choose(self, role: int, messages: list, seed: int, intervention: str, m: Matrix) -> int:
        if self.mode == "synthetic":
            rng = np.random.default_rng(stable_seed("syn", role, seed, intervention, m.matrix_id))
            t = m.target()[role]
            if intervention.startswith("RoleBound"):
                return t if rng.random() < 0.97 else int(rng.integers(N))
            probs = rng.dirichlet(np.ones(N) * 1.5)
            return int(rng.choice(N, p=probs))
        endpoint = self.cfg["endpoints"][role].rstrip("/") + "/chat/completions"
        body = {"model": self.cfg["models"][role], "messages": messages,
                "temperature": self.sampling["temperature"], "top_p": self.sampling["top_p"],
                "max_tokens": self.sampling["max_tokens"], "seed": seed}
        key = os.environ.get(self.cfg.get("api_key_env", ""), "")
        last = None
        for attempt in range(self.max_retries + 1):
            body["seed"] = seed + 7919 * attempt
            req = request.Request(endpoint, data=json.dumps(body).encode(), method="POST",
                                  headers={"Content-Type": "application/json",
                                           "Authorization": f"Bearer {key}"})
            try:
                with request.urlopen(req, timeout=120) as r:
                    text = json.loads(r.read())["choices"][0]["message"]["content"]
                return parse_action(text)
            except ValueError as e:            # parse failure -> retry w/ new seed
                self.parse_retries += 1
                last = e
            except Exception as e:             # transient HTTP -> backoff retry
                last = e
                time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"backend failed after retries: {last}")


# ----------------------------------------------------------------- rollouts
def play_episodes(backend, m, seed, intervention, n_episodes, sampling, ep_offset=0):
    steps_all, episodes = [], []
    horizon, memory = sampling["horizon"], sampling["memory"]
    for ep in range(n_episodes):
        history, ep_steps = [], []
        for st in range(horizon):
            acts = [backend.choose(r, prompt(m, r, history, intervention, memory),
                                   stable_seed(seed, ep + ep_offset, st, r, intervention, m.matrix_id),
                                   intervention, m) for r in range(2)]
            rew = list(m.payoff[acts[0]][acts[1]])
            step = {"actions": acts, "rewards": rew}
            history.append(step)
            ep_steps.append(step)
        episodes.append(ep_steps)
        steps_all.extend(ep_steps)
    return episodes, steps_all


def metrics_from(warm_steps, commit_steps, m):
    t = tuple(m.target())
    all_steps = warm_steps + commit_steps
    team = float(np.mean([np.mean(s["rewards"]) for s in all_steps]))
    r1 = float(np.mean([s["rewards"][0] for s in all_steps]))
    r2 = float(np.mean([s["rewards"][1] for s in all_steps]))
    fid = (float(np.mean([tuple(s["actions"]) == t for s in commit_steps]))
           if commit_steps else 0.0)
    return {"total_horizon_team_mean_payoff": team,
            "total_horizon_role1_mean_payoff": r1,
            "total_horizon_role2_mean_payoff": r2,
            "commit_target_action_rate": fid,
            "n_warmup_steps": len(warm_steps), "n_commit_steps": len(commit_steps)}


def run_cell(protocol, root, phase, m, seed, backend, selected=None):
    cfg = protocol[phase]
    base = root / phase.upper() / protocol["model_pair"]["profile"] / m.matrix_id / f"seed_{seed}"
    if (base / "arms" / "NoAlign" / "metrics.json").exists():
        return
    sampling = protocol["sampling"]
    _, warm = play_episodes(backend, m, seed, "NoAlign", sampling["warmup_episodes"], sampling)
    dump(base / "matrix.json", m.audit())
    dump(base / "warmup.json", {"steps": warm})

    arm_map = {"NoAlign": "NoAlign", "RoleBoundConfirm": "RoleBoundConfirm",
               "RoleBoundAcknowledge": "RoleBoundAcknowledge", "RoleBoundSelected": selected}
    commits = {}
    for arm in cfg["actual_arms"]:
        cue = arm_map[arm]
        _, commit = play_episodes(backend, m, seed, "NoAlign" if cue == "NoAlign" else cue,
                                  sampling["commit_episodes"], sampling,
                                  ep_offset=sampling["warmup_episodes"])
        commits[arm] = commit
        dump(base / "arms" / arm / "commit_trajectories.json", {"steps": commit})
        met = metrics_from(warm, commit, m)
        met.update({"policy": arm, "selected_intervention": cue})
        dump(base / "arms" / arm / "metrics.json", met)

    if phase == "p9":
        a_v = actionsafe_verdict(warm, m, protocol["action_safety"], stable_seed("as", seed, m.matrix_id))
        o_v = oldgate_verdict(warm, protocol["legacy_safety"], stable_seed("og", seed, m.matrix_id))
        for policy, verdict in (("ActionSafeFixed", a_v), ("OldGateFixed", o_v)):
            src = "RoleBoundSelected" if verdict["safety_pass"] else "NoAlign"
            met = metrics_from(warm, commits[src], m)
            met.update({"policy": policy, "selected_intervention": src,
                        "counterfactual_source_policy": src,
                        "counterfactual_common_random_numbers": True})
            dump(base / "arms" / policy / "metrics.json", met)
            dump(base / "arms" / policy / "decision.json", verdict)


# ----------------------------------------------------------------- analysis
def bootstrap(per_matrix: dict[str, list[float]], draws: int, seed: int) -> dict:
    means = np.asarray([float(np.mean(v)) for v in per_matrix.values()])
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(means), size=(draws, len(means)))
    boot = means[idx].mean(axis=1)
    return {"mean": float(means.mean()),
            "ci95": [float(np.quantile(boot, .025)), float(np.quantile(boot, .975))],
            "n_matrices": len(means)}


def analyze(protocol, root, phase):
    cfg = protocol[phase]
    fams = ["anti_safe"] if phase == "p9d" else cfg["families"]
    npf = cfg.get("n_anti_safe_matrices", cfg.get("n_per_family"))
    specs = registry(cfg["registry_seed"], npf, fams)
    base = root / phase.upper() / protocol["model_pair"]["profile"]
    rows, missing = [], []
    for m in specs:
        for seed in cfg["seeds"]:
            cell = base / m.matrix_id / f"seed_{seed}"
            if not (cell / "arms" / "NoAlign" / "metrics.json").exists():
                missing.append(str(cell))
                continue
            rows.append((m, cell, load(cell / "arms" / "NoAlign" / "metrics.json")))

    draws = protocol["analysis"]["bootstrap_samples"]
    if phase == "p9d":
        res = {"phase": "p9d", "integrity": {"missing": missing}, "variants": {}, "noalign_entropy": {}}
        ent = {0: [], 1: []}
        for m, cell, _ in rows:
            for r, s in ((r, s) for r in range(2)
                         for s in load(cell / "warmup.json")["steps"]):
                ent[r].append(s["actions"][r])
        for r in range(2):
            p = np.bincount(ent[r], minlength=N) / max(len(ent[r]), 1)
            res["noalign_entropy"][f"role_{r+1}"] = float(-sum(x * np.log(x) for x in p if x > 0))
        for arm in cfg["candidate_prompts"]:
            vals = {}
            for m, cell, _ in rows:
                vals.setdefault(m.matrix_id, []).append(
                    load(cell / "arms" / arm / "metrics.json")["commit_target_action_rate"])
            res["variants"][arm] = bootstrap(vals, cfg["selection_bootstrap_draws"], stable_seed("p9d", arm))
        valid = [(v["mean"], k) for k, v in res["variants"].items() if v["ci95"][0] >= .50]
        entropy_ok = all(v >= 0.8 for v in res["noalign_entropy"].values())
        res["selected_prompt"] = sorted(valid, key=lambda x: (-x[0], x[1]))[0][1] if valid else None
        res["selection_success"] = bool(valid) and not missing and entropy_ok
        dump(root / "P9D_ANALYSIS.json", res)
        dump(root / "P9D_SELECTION.json",
             {"selected_prompt": res["selected_prompt"],
              "selection_success": res["selection_success"],
              "protocol_sha256": sha(Path(sys.argv[sys.argv.index("--protocol") + 1]))})
        return res

    policies = ["RoleBoundSelected", "ActionSafeFixed", "OldGateFixed"]
    res = {"phase": "p9", "integrity": {"missing": missing}, "families": {}}
    for fam in fams:
        fam_rows = [r for r in rows if r[0].family == fam]
        res["families"][fam] = {}
        for pol in policies:
            eff, eff1, eff2, fid, rate = {}, {}, {}, {}, []
            for m, cell, no in fam_rows:
                x = load(cell / "arms" / pol / "metrics.json")
                eff.setdefault(m.matrix_id, []).append(
                    x["total_horizon_team_mean_payoff"] - no["total_horizon_team_mean_payoff"])
                eff1.setdefault(m.matrix_id, []).append(
                    x["total_horizon_role1_mean_payoff"] - no["total_horizon_role1_mean_payoff"])
                eff2.setdefault(m.matrix_id, []).append(
                    x["total_horizon_role2_mean_payoff"] - no["total_horizon_role2_mean_payoff"])
                fid.setdefault(m.matrix_id, []).append(x["commit_target_action_rate"])
                rate.append(float(x["selected_intervention"] != "NoAlign"))
            res["families"][fam][pol] = {
                "effect_vs_noalign": bootstrap(eff, draws, stable_seed("e", fam, pol)),
                "role1_effect": bootstrap(eff1, draws, stable_seed("e1", fam, pol)),
                "role2_effect": bootstrap(eff2, draws, stable_seed("e2", fam, pol)),
                "target_fidelity": bootstrap(fid, draws, stable_seed("f", fam, pol)),
                "intervention_rate": float(np.mean(rate))}
    a = res["families"]["anti_safe"]["ActionSafeFixed"]
    t = res["families"]["anti_tradeoff"]["ActionSafeFixed"]
    o = res["families"]["anti_safe"]["OldGateFixed"]
    res["confirmatory_success"] = bool(
        not missing
        and a["target_fidelity"]["ci95"][0] > .50
        and a["effect_vs_noalign"]["ci95"][0] > 0
        and a["role1_effect"]["ci95"][0] > 0 and a["role2_effect"]["ci95"][0] > 0
        and a["intervention_rate"] >= .80
        and t["intervention_rate"] <= .10
        and o["intervention_rate"] <= .10)
    dump(root / "P9_ANALYSIS.json", res)
    return res


# ----------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--protocol", type=Path, required=True)
    ap.add_argument("--results-root", type=Path, required=True)
    ap.add_argument("--phase", choices=["p9d", "p9"], required=True)
    ap.add_argument("--backend", choices=["vllm", "synthetic"], default="vllm")
    ap.add_argument("--workers", type=int, default=48)
    ap.add_argument("--analyze", action="store_true")
    args = ap.parse_args()
    protocol = load(args.protocol)
    root = args.results_root.resolve()
    cfg = protocol[args.phase]

    if args.analyze:
        print(json.dumps(analyze(protocol, root, args.phase), indent=2))
        return

    selected = None
    if args.phase == "p9":
        sel = load(root / protocol["p9"]["selected_prompt_file"])
        if not sel.get("selection_success") or sel.get("selected_prompt") not in protocol["p9d"]["candidate_prompts"]:
            raise RuntimeError("P9 is blocked: P9D did not freeze a valid presentation")
        selected = sel["selected_prompt"]

    fams = ["anti_safe"] if args.phase == "p9d" else cfg["families"]
    npf = cfg.get("n_anti_safe_matrices", cfg.get("n_per_family"))
    specs = registry(cfg["registry_seed"], npf, fams)
    dump(root / f"{args.phase.upper()}_REGISTRY.json",
         {"protocol_sha256": sha(args.protocol), "matrices": [m.audit() for m in specs]})

    backend = Backend(protocol["model_pair"], protocol["sampling"], args.backend,
                      protocol["execution"]["max_retries"])
    tasks = [(m, s) for m in specs for s in cfg["seeds"]]
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(run_cell, protocol, root, args.phase, m, s, backend, selected)
                for m, s in tasks]
        done = 0
        for f in as_completed(futs):
            f.result()
            done += 1
            if done % 50 == 0:
                print(f"  {done}/{len(tasks)} cells  ({time.time()-t0:.0f}s, "
                      f"parse-retries={backend.parse_retries})", flush=True)
    print(json.dumps({"phase": args.phase, "complete": True, "contexts": len(tasks),
                      "elapsed_seconds": round(time.time() - t0, 1),
                      "parse_retries": backend.parse_retries,
                      "next": "rerun with --analyze"}, indent=2))


if __name__ == "__main__":
    main()
