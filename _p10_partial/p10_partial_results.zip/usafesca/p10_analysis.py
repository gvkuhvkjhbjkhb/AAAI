"""Analysis for the P10 factorial: identification, CIs, and the frozen verdict.

Everything here is pre-registered in ``protocols/p10_factorial_frozen.json``:
the estimands, the clustering unit, the interval methods, the equivalence
bounds, and the decision rules that map a result onto a specific edit to the
paper.  Running this file is the only step that turns rollouts into a claim, and
it prints the claim it is entitled to -- including "indeterminate".

Estimands (fidelity = fraction of committed steps on which the pair plays the
advised *joint profile*; the per-role variant is carried alongside because M3
shows the paper has been mixing the two):

    dP(r)   = f(r, RoleBound) - f(r, Advisory)          presentation effect, within registry r
    dR(p)   = f(R_rq5, p)     - f(R_rq3, p)             registry effect, within presentation p
    inter   = dP(R_rq5) - dP(R_rq3)                     interaction

``dP`` is estimated on *paired* cells (same matrix, same relabelling, same seed,
same warm-up block), which is why it is far tighter than the raw arm means.
``dR`` cannot be paired -- the registries contain different games -- so it is a
difference of two independent clustered means and is reported with the honest,
wider interval that implies.

Clustering is on the base matrix id (G = number of matrices).  Following the
paper's own supplement D and reviewer M4, every interval is reported three ways:
percentile-cluster (the paper's method), wild-cluster bootstrap-t (Cameron,
Gelbach & Miller; the small-G fix) and cluster-t(G-1).  The *decision rules read
the wild-cluster interval*, not the percentile one.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Iterable

import numpy as np

import cluster_ci
from common import read_json, write_json

PRIMARY = "fidelity_joint_profile"


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def load_long(root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    cells_dir = Path(root) / "cells"
    if not cells_dir.exists():
        return rows
    for metrics_path in sorted(cells_dir.glob("*/*/*/*/*/arms/*/metrics.json")):
        seed_dir = metrics_path.parents[2]
        try:
            cell = read_json(seed_dir / "cell.json")
            warm = read_json(seed_dir / "warmup.json")
            met = read_json(metrics_path)
        except FileNotFoundError:
            continue
        rows.append({
            "pair_id": cell["pair_id"], "registry": cell["registry"], "matrix_id": cell["matrix_id"],
            "family": cell["family"], "seed": cell["seed"], "relabel": cell["relabel"],
            "arm": metrics_path.parent.name,
            "actionsafe_permits": bool(warm["action_summary"]["safety_pass"]),
            "oldgate_permits": bool(warm["legacy_summary"]["safety_pass"]),
            **met,
            # after **met so the hashable tuple wins over the JSON list
            "target_cell": tuple(cell["target_cell"]),
        })
    return rows


def _sel(rows: Iterable[dict[str, Any]], **kw: Any) -> list[dict[str, Any]]:
    out = list(rows)
    for k, v in kw.items():
        if v is None:
            continue
        out = [r for r in out if r.get(k) == v]
    return out


# ---------------------------------------------------------------------------
# Interval machinery
# ---------------------------------------------------------------------------
def _cluster_t(values: np.ndarray, groups: np.ndarray, alpha: float = 0.05) -> list[float]:
    means, _ = cluster_ci._group_means(values, groups)
    G = len(means)
    if G < 2:
        return [float("nan"), float("nan")]
    xbar, se = float(means.mean()), float(means.std(ddof=1) / math.sqrt(G))
    try:  # scipy is optional in this package
        from scipy import stats
        crit = float(stats.t.ppf(1 - alpha / 2, df=G - 1))
    except Exception:
        crit = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365,
                8: 2.306, 9: 2.262, 10: 2.228, 15: 2.131, 20: 2.086, 23: 2.069}.get(G - 1, 1.96)
    return [xbar - crit * se, xbar + crit * se]


def summarize(values: list[float], groups: list[str], seed: int = 0, label: str = "") -> dict[str, Any]:
    """Cluster-robust summary of one estimand, three interval methods, with G."""
    x = np.asarray([v for v in values], float)
    g = np.asarray(groups)
    ok = ~np.isnan(x)
    x, g = x[ok], g[ok]
    if not len(x):
        return {"label": label, "n_obs": 0, "G": 0, "mean": float("nan"),
                "percentile_cluster": [float("nan")] * 2, "wild_cluster": [float("nan")] * 2,
                "cluster_t": [float("nan")] * 2, "degenerate": True}
    means, _ = cluster_ci._group_means(x, g)
    degenerate = bool(np.allclose(means, means[0]))
    out = {
        "label": label, "n_obs": int(len(x)), "G": int(len(np.unique(g))),
        "mean": float(means.mean()),
        "percentile_cluster": list(cluster_ci.cluster_bootstrap_ci(x, g, n_boot=20000, seed=seed)),
        "wild_cluster": list(cluster_ci.wild_cluster_bootstrap_ci(x, g, n_boot=20000, seed=seed)),
        "cluster_t": _cluster_t(x, g),
        # A degenerate estimand (every cluster identical, e.g. fidelity exactly
        # 1.000 everywhere) has no sampling variation to report.  M4 objects to
        # printing [1.000, 1.000] as if it were an interval, so we flag it.
        "degenerate": degenerate,
    }
    if degenerate:
        out["interval_note"] = ("all clusters identical: this is a point mass, not an interval; "
                                "report as a bound, e.g. >= 1 - 3/n by the rule of three")
        n = int(len(x))
        out["rule_of_three_lower_bound"] = float(max(0.0, means.mean() - 3.0 / max(n, 1)))
    return out


def tost(values: list[float], groups: list[str], bound: float, seed: int = 0) -> dict[str, Any]:
    """Two one-sided tests for equivalence to zero within +/- ``bound``.

    Implemented on the wild-cluster interval: the estimand is declared
    equivalent to zero when that 90% interval (two one-sided 5% tests) lies
    inside the bounds.  A *null result therefore means something* -- which is the
    whole point of asking whether presentation had no effect.
    """
    x = np.asarray(values, float)
    g = np.asarray(groups)
    ok = ~np.isnan(x)
    x, g = x[ok], g[ok]
    if len(x) < 2:
        return {"equivalent": False, "reason": "insufficient_data"}
    lo, hi = cluster_ci.wild_cluster_bootstrap_ci(x, g, n_boot=20000, alpha=0.10, seed=seed)
    return {"equivalence_bound": bound, "ci90_wild_cluster": [lo, hi],
            "equivalent": bool(lo > -bound and hi < bound)}


# ---------------------------------------------------------------------------
# Estimands
# ---------------------------------------------------------------------------
def paired_presentation_effect(rows: list[dict[str, Any]], pair_id: str, registry: str,
                               family: str | None, metric: str = PRIMARY,
                               arms: tuple[str, str] = ("RoleBound", "Advisory")) -> dict[str, Any]:
    """dP(registry): paired within (matrix, relabel, seed) -- CRN-matched."""
    hi = {(r["matrix_id"], r["relabel"], r["seed"]): r
          for r in _sel(rows, pair_id=pair_id, registry=registry, family=family, arm=arms[0])}
    lo = {(r["matrix_id"], r["relabel"], r["seed"]): r
          for r in _sel(rows, pair_id=pair_id, registry=registry, family=family, arm=arms[1])}
    keys = sorted(set(hi) & set(lo))
    vals = [float(hi[k][metric]) - float(lo[k][metric]) for k in keys]
    return summarize(vals, [k[0] for k in keys], seed=abs(hash(("dP", pair_id, registry, family))) % 10 ** 6,
                     label=f"dP[{pair_id}|{registry}|{family or 'all'}] = {arms[0]} - {arms[1]} ({metric})")


def unpaired_registry_effect(rows: list[dict[str, Any]], pair_id: str, arm: str, family: str | None,
                             metric: str = PRIMARY, *,
                             registries: tuple[str, str] = ("R_rq5", "R_rq3")) -> dict[str, Any]:
    """dR(presentation): difference of two independent clustered means."""
    a = _sel(rows, pair_id=pair_id, registry=registries[0], family=family, arm=arm)
    b = _sel(rows, pair_id=pair_id, registry=registries[1], family=family, arm=arm)
    if not a or not b:
        return {"label": f"dR[{pair_id}|{arm}|{family or 'all'}]", "G": 0, "mean": float("nan"),
                "percentile_cluster": [float("nan")] * 2, "wild_cluster": [float("nan")] * 2,
                "cluster_t": [float("nan")] * 2, "degenerate": True, "n_obs": 0}
    rng = np.random.default_rng(abs(hash(("dR", pair_id, arm, family))) % (2 ** 31))
    boots = []
    ga = _by_matrix(a, metric)
    gb = _by_matrix(b, metric)
    ma, mb = np.asarray(list(ga.values())), np.asarray(list(gb.values()))
    for _ in range(20000):
        boots.append(ma[rng.integers(0, len(ma), len(ma))].mean() - mb[rng.integers(0, len(mb), len(mb))].mean())
    boots = np.asarray(boots)
    return {"label": f"dR[{pair_id}|{arm}|{family or 'all'}] = {registries[0]} - {registries[1]} ({metric})",
            "mean": float(ma.mean() - mb.mean()), "G": int(len(ma) + len(mb)),
            "G_by_registry": {registries[0]: int(len(ma)), registries[1]: int(len(mb))},
            "n_obs": len(a) + len(b),
            "percentile_cluster": [float(np.quantile(boots, .025)), float(np.quantile(boots, .975))],
            "wild_cluster": None, "cluster_t": None,
            "note": "unpaired: no wild-cluster analogue for a two-sample difference at this G; "
                    "read the percentile interval as optimistic",
            "degenerate": bool(np.allclose(boots, boots[0]))}


def _by_matrix(rows: list[dict[str, Any]], metric: str) -> dict[str, float]:
    out: dict[str, list[float]] = {}
    for r in rows:
        v = float(r[metric])
        if not math.isnan(v):
            out.setdefault(r["matrix_id"], []).append(v)
    return {k: float(np.mean(v)) for k, v in out.items()}


def interaction(rows: list[dict[str, Any]], pair_id: str, family: str | None,
                metric: str = PRIMARY) -> dict[str, Any]:
    """dP(R_rq5) - dP(R_rq3): does presentation act differently across registries?"""
    a = paired_presentation_effect(rows, pair_id, "R_rq5", family, metric)
    b = paired_presentation_effect(rows, pair_id, "R_rq3", family, metric)
    return {"label": f"interaction[{pair_id}|{family or 'all'}]",
            "dP_R_rq5": a, "dP_R_rq3": b,
            "point_estimate": (a["mean"] - b["mean"]) if not (math.isnan(a["mean"]) or math.isnan(b["mean"])) else float("nan")}


def arm_level(rows: list[dict[str, Any]], pair_id: str, registry: str | None, arm: str,
              family: str | None, metric: str = PRIMARY) -> dict[str, Any]:
    sel = _sel(rows, pair_id=pair_id, registry=registry, family=family, arm=arm)
    return summarize([float(r[metric]) for r in sel], [r["matrix_id"] for r in sel],
                     seed=abs(hash(("lvl", pair_id, registry, arm, family))) % 10 ** 6,
                     label=f"f[{pair_id}|{registry or 'both'}|{arm}|{family or 'all'}] ({metric})")


# ---------------------------------------------------------------------------
# Secondary: does the certificate matter *more* when compliance is high?
# ---------------------------------------------------------------------------
def harm_exposure(rows: list[dict[str, Any]], pair_id: str, family: str = "anti_tradeoff",
                  arm: str = "RoleBound") -> dict[str, Any]:
    """Realized role-shortfall on targets the legacy gate would permit.

    The paper's own logic implies a prediction that reviewer M11 does not
    anticipate: if a strong pair complies more, then a *wrongly* authorized
    target is realized more completely, so the marginal value of (C2)/(C3) grows
    with capability.  This computes, per matrix, the realized shortfall of the
    worse-off role against its own warm-up baseline under the arm the gate would
    route to, restricted to cells the legacy gate permits.
    """
    sel = [r for r in _sel(rows, pair_id=pair_id, family=family, arm=arm) if r["oldgate_permits"]]
    vals, groups = [], []
    for r in sel:
        shortfall = min(float(r["commit_role_means"][i]) - float(r["warmup_role_means"][i]) for i in range(2))
        vals.append(min(0.0, shortfall))
        groups.append(r["matrix_id"])
    all_cells = _sel(rows, pair_id=pair_id, family=family, arm=arm)
    return {"family": family, "arm": arm,
            "n_oldgate_permitted_cells": len(sel), "n_cells": len(all_cells),
            "oldgate_permit_rate": (len(sel) / len(all_cells)) if all_cells else float("nan"),
            "realized_worst_role_shortfall": summarize(vals, groups, label=f"harm_exposure[{pair_id}]"),
            "mean_fidelity_on_permitted": float(np.mean([float(r[PRIMARY]) for r in sel])) if sel else float("nan")}


# ---------------------------------------------------------------------------
# Integrity and validity checks
# ---------------------------------------------------------------------------
def integrity(protocol: dict[str, Any], root: Path, rows: list[dict[str, Any]]) -> dict[str, Any]:
    import p10_runner
    expected = p10_runner.enumerate_cells(protocol)
    arms = list(protocol["design"]["presentations"])
    have = {(r["pair_id"], r["registry"], r["matrix_id"], r["relabel"], r["seed"], r["arm"]) for r in rows}
    missing = [f"{c['pair_id']}/{c['registry']}/{c['matrix_id']}/rl{c['relabel']}/seed_{c['seed']}/{a}"
               for c in expected for a in arms
               if (c["pair_id"], c["registry"], c["matrix_id"], c["relabel"], c["seed"], a) not in have]
    attempted = sum(int(r.get("commit_steps_attempted", 0)) for r in rows)
    completed = sum(int(r.get("commit_steps_completed", 0)) for r in rows)
    unparse = sum(int(r.get("unparseable_responses", 0)) for r in rows)
    trunc = sum(int(r.get("truncated_episodes", 0)) for r in rows)
    degraded = [f"{r['pair_id']}/{r['registry']}/{r['matrix_id']}/rl{r['relabel']}/seed_{r['seed']}/{r['arm']}"
                for r in rows
                if r.get("commit_steps_attempted") and
                r["commit_steps_completed"] / r["commit_steps_attempted"] < float(
                    protocol["analysis"].get("min_cell_completion", 0.95))]
    # Relabel balance: with a balanced assignment each permutation should appear
    # equally often, otherwise the positional-bias control is not doing its job.
    balance: dict[str, dict[str, int]] = {}
    for r in rows:
        balance.setdefault(r["registry"], {}).setdefault(r["relabel"], 0)
        balance[r["registry"]][r["relabel"]] += 1
    return {"missing_cells": missing[:200], "n_missing_cells": len(missing),
            "commit_steps_attempted": attempted, "commit_steps_completed": completed,
            "unparseable_responses": unparse, "truncated_episodes": trunc,
            "unparseable_rate": (unparse / attempted) if attempted else 0.0,
            "degraded_cells": degraded[:200], "n_degraded_cells": len(degraded),
            "relabel_balance": balance,
            "all_checks_pass": bool(not missing and not degraded)}


def positional_bias(rows: list[dict[str, Any]], pair_id: str, arm: str) -> dict[str, Any]:
    """Fidelity conditional on where the target sits, per relabelling.

    If the endpoint were being carried by a bias towards the first-listed
    action, fidelity would move with the target cell.  This makes that visible
    instead of assuming it away.
    """
    out: dict[str, Any] = {}
    sel = _sel(rows, pair_id=pair_id, arm=arm)
    for cell in sorted({r["target_cell"] for r in sel}):
        sub = [r for r in sel if r["target_cell"] == cell]
        out[f"target_{cell[0]}{cell[1]}"] = summarize([float(r[PRIMARY]) for r in sub],
                                                      [r["matrix_id"] for r in sub],
                                                      label=f"fidelity|target={cell}")
    spread = [v["mean"] for v in out.values() if not math.isnan(v["mean"])]
    out["max_minus_min_across_target_cells"] = float(max(spread) - min(spread)) if len(spread) > 1 else 0.0
    return out


# ---------------------------------------------------------------------------
# Pre-registered decision rules
# ---------------------------------------------------------------------------
def decide_m4(res: dict[str, Any], rules: dict[str, Any], pair_id: str, reg_rq3: str) -> dict[str, Any]:
    dP = res["presentation_effects"][pair_id][reg_rq3]["all"]
    dR = res["registry_effects"][pair_id]["Advisory"]["all"]
    eq = res["equivalence"][pair_id][reg_rq3]
    lo = dP["wild_cluster"][0] if dP.get("wild_cluster") else float("nan")
    strong = (not math.isnan(lo)) and lo >= rules["presentation_effect_lower_bound"]
    reg_big = (not math.isnan(dR["mean"])) and dR["percentile_cluster"][0] >= rules["registry_effect_lower_bound"]
    if strong:
        verdict = "PRESENTATION_CAUSAL"
        action = ("RQ5's claim survives the de-confound.  Restate it within a registry: 'on RQ3's own "
                  "registry, changing only the presentation moves fidelity by dP', and keep it in the "
                  "contribution list.")
    elif eq["equivalent"] and reg_big:
        verdict = "REGISTRY_EXPLAINS"
        action = ("The 0.28 -> 1.00 jump was the registry, not the presentation.  Withdraw the second "
                  "contribution as stated, move RQ5 to an observation, and rewrite the abstract sentence.")
    elif eq["equivalent"]:
        verdict = "BOTH_SMALL"
        action = ("Neither factor reproduces the jump under one harness; the original gap was driven by "
                  "harness differences (runner, max_tokens, episode split).  Report that and drop the claim.")
    else:
        verdict = "INDETERMINATE"
        action = ("Underpowered or mixed.  Per supplement D's own rule, report as descriptive, keep the "
                  "confound disclosure in the main text, and remove RQ5 from the contribution list.")
    return {"verdict": verdict, "required_paper_edit": action,
            "dP_on_R_rq3": dP, "dR_under_Advisory": dR, "equivalence_test": eq}


def decide_m11(res: dict[str, Any], rules: dict[str, Any], weak_pair: str, strong_pairs: list[str],
               reg_rq3: str) -> dict[str, Any]:
    out: dict[str, Any] = {"per_pair": {}}
    verdicts = []
    for pid in strong_pairs:
        adv = res["arm_levels"].get(pid, {}).get(reg_rq3, {}).get("Advisory", {}).get("all")
        rb = res["arm_levels"].get(pid, {}).get(reg_rq3, {}).get("RoleBound", {}).get("all")
        if not adv or math.isnan(adv["mean"]):
            out["per_pair"][pid] = {"verdict": "NO_DATA"}
            continue
        adv_lo = adv["wild_cluster"][0] if adv.get("wild_cluster") else adv["mean"]
        adv_hi = adv["wild_cluster"][1] if adv.get("wild_cluster") else adv["mean"]
        rb_lo = (rb or {}).get("wild_cluster", [float("nan")])[0] if rb else float("nan")
        if adv_lo >= rules["strong_pair_ceiling_lower_bound"]:
            v = "CAPABILITY_ACCOUNT"
            action = ("A strong pair already complies at ceiling under the plain advisory.  The realization "
                      "gap as written is a property of weak instruction-followers, not of the interface.  "
                      "Rewrite contribution 2 as scope: 'for pairs below capability tier X, authorization "
                      "does not imply realization', and move the interface framing to Discussion.  Then run "
                      "the harm-exposure corollary: at fidelity ~1 the *certificate* is what stands between "
                      "an OldGate false permit and a fully realized loss -- which strengthens contribution 1.")
        elif (not math.isnan(adv_hi)) and adv_hi <= rules["strong_pair_gap_upper_bound"] and \
                (not math.isnan(rb_lo)) and rb_lo >= rules["rolebound_ceiling_lower_bound"]:
            v = "INTERFACE_SURVIVES"
            action = ("A strong pair still under-complies with the plain advisory and is lifted by the "
                      "role-bound presentation.  Contribution 2 survives capability scaling; report the "
                      "capability ladder as direct evidence and cite this pair in the abstract.")
        else:
            v = "PARTIAL"
            action = ("Fidelity is neither at ceiling nor clearly depressed.  Report the ladder, state that "
                      "capability and presentation both contribute, and weaken 'interface variable' to "
                      "'jointly determined by capability and presentation'.")
        verdicts.append(v)
        out["per_pair"][pid] = {"verdict": v, "advisory_fidelity": adv, "rolebound_fidelity": rb,
                                "required_paper_edit": action}
    out["overall"] = ("CAPABILITY_ACCOUNT" if verdicts and all(v == "CAPABILITY_ACCOUNT" for v in verdicts)
                      else "INTERFACE_SURVIVES" if verdicts and all(v == "INTERFACE_SURVIVES" for v in verdicts)
                      else "MIXED" if verdicts else "NO_DATA")
    out["weak_pair_reference"] = res["arm_levels"].get(weak_pair, {}).get(reg_rq3, {}).get("Advisory", {}).get("all")
    return out


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def analyze(protocol: dict[str, Any], root: Path) -> dict[str, Any]:
    root = Path(root)
    rows = load_long(root)
    design, acfg = protocol["design"], protocol["analysis"]
    pairs = sorted({r["pair_id"] for r in rows}) or [p["pair_id"] for p in protocol["pairs"] if p.get("enabled", True)]
    families: list[str | None] = [None] + list(design["families"])
    metrics = [PRIMARY] + list(acfg.get("secondary_metrics", []))
    reg3, reg5 = acfg["registry_of_rq3"], acfg["registry_of_rq5"]

    from p10_registry import build_registry, legacy_subset, registry_descriptors
    legacy_ids = {reg: set(legacy_subset(build_registry(reg, design["families"], design.get("n_per_family")), reg))
                  for reg in design["registries"]}

    res: dict[str, Any] = {
        "campaign": protocol["campaign"], "primary_metric": PRIMARY,
        "registry_descriptors": {
            reg: registry_descriptors(build_registry(reg, design["families"], design.get("n_per_family")))["by_family"]
            for reg in design["registries"]},
        "integrity": integrity(protocol, root, rows),
        "arm_levels": {}, "presentation_effects": {}, "registry_effects": {},
        "interactions": {}, "equivalence": {}, "positional_bias": {}, "harm_exposure": {},
        "secondary_metric_views": {},
    }
    for pid in pairs:
        res["arm_levels"][pid] = {}
        for reg in design["registries"]:
            res["arm_levels"][pid][reg] = {}
            for arm in design["presentations"] + ["ActionSafeFixed", "OldGateFixed"]:
                res["arm_levels"][pid][reg][arm] = {
                    (fam or "all"): arm_level(rows, pid, reg, arm, fam) for fam in families}
        res["presentation_effects"][pid] = {
            reg: {(fam or "all"): paired_presentation_effect(rows, pid, reg, fam) for fam in families}
            for reg in design["registries"]}
        res["registry_effects"][pid] = {
            arm: {(fam or "all"): unpaired_registry_effect(rows, pid, arm, fam, registries=(reg5, reg3))
                  for fam in families}
            for arm in design["presentations"]}
        res["interactions"][pid] = {(fam or "all"): interaction(rows, pid, fam) for fam in families}
        # The subset that is bit-identical to the archived campaigns, so the new
        # numbers can be laid beside the old ones without a pooling caveat.
        res.setdefault("legacy_matched_view", {})[pid] = {
            reg: paired_presentation_effect([r for r in rows if r["matrix_id"] in legacy_ids[reg]], pid, reg, None)
            for reg in design["registries"]}
        res["equivalence"][pid] = {}
        for reg in design["registries"]:
            hi = {(r["matrix_id"], r["relabel"], r["seed"]): r for r in _sel(rows, pair_id=pid, registry=reg, arm="RoleBound")}
            lo = {(r["matrix_id"], r["relabel"], r["seed"]): r for r in _sel(rows, pair_id=pid, registry=reg, arm="Advisory")}
            keys = sorted(set(hi) & set(lo))
            res["equivalence"][pid][reg] = tost([float(hi[k][PRIMARY]) - float(lo[k][PRIMARY]) for k in keys],
                                                [k[0] for k in keys], float(acfg["equivalence_bound"]))
        res["positional_bias"][pid] = {arm: positional_bias(rows, pid, arm) for arm in design["presentations"]}
        res["harm_exposure"][pid] = harm_exposure(rows, pid)
        res["secondary_metric_views"][pid] = {
            m: {reg: paired_presentation_effect(rows, pid, reg, None, m) for reg in design["registries"]}
            for m in metrics if m != PRIMARY}

    rules = acfg["decision_rules"]
    weak = acfg["reference_weak_pair"]
    reg3, reg5 = acfg["registry_of_rq3"], acfg["registry_of_rq5"]
    strong = [p["pair_id"] for p in protocol["pairs"]
              if p.get("capability_tier") == "strong" and p["pair_id"] in pairs]
    res["verdicts"] = {
        "M4_registry_vs_presentation": (decide_m4(res, rules, weak, reg3) if weak in pairs
                                        else {"verdict": "NO_DATA", "reason": f"no rows for {weak}"}),
        "M11_capability_vs_interface": decide_m11(res, rules, weak, strong, reg3),
    }
    # A capability ladder table, ordered as the protocol declares it.
    lvl = lambda pid, reg, arm: res["arm_levels"].get(pid, {}).get(reg, {}).get(arm, {}).get("all", {}).get("mean")
    res["capability_ladder"] = [
        {"pair_id": p["pair_id"], "label": p.get("label"), "tier": p.get("capability_tier"),
         f"advisory_fidelity_{reg3}": lvl(p["pair_id"], reg3, "Advisory"),
         f"rolebound_fidelity_{reg3}": lvl(p["pair_id"], reg3, "RoleBound"),
         f"advisory_fidelity_{reg5}": lvl(p["pair_id"], reg5, "Advisory"),
         f"rolebound_fidelity_{reg5}": lvl(p["pair_id"], reg5, "RoleBound")}
        for p in protocol["pairs"] if p["pair_id"] in pairs]
    write_json(root / "P10_ANALYSIS.json", res)
    return res


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--protocol", type=Path, required=True)
    ap.add_argument("--results-root", type=Path, required=True)
    args = ap.parse_args()
    print(json.dumps(analyze(read_json(args.protocol), args.results_root), indent=2))


if __name__ == "__main__":
    main()
