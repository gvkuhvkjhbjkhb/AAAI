"""P4-only utility-delta model and fail-closed P5 decision rule."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from common import read_json, sha256_value, write_json
from matrix_registry import controller_features


@dataclass
class ArmModel:
    coefficients: list[float]
    inverse_gram: list[list[float]]
    residual_variance: float
    degrees_of_freedom: int
    n_rows: int

    def predict(self, x: np.ndarray, z: float) -> tuple[float, float, float]:
        beta = np.asarray(self.coefficients, dtype=float)
        inv = np.asarray(self.inverse_gram, dtype=float)
        mean = float(x @ beta)
        # Predictive rather than mean-only uncertainty: conservative for unseen contexts.
        se = float(np.sqrt(max(self.residual_variance, 1e-12) * (1.0 + x @ inv @ x)))
        return mean, se, mean - z * se


def _metric_paths(p4_root: Path, profile: str) -> list[Path]:
    return sorted((p4_root / profile).glob("*/seed_*/arms/NoAlign/metrics.json"))


def fit_from_p4(protocol: dict[str, Any], p4_root: Path, profile: str) -> dict[str, Any]:
    rows: dict[str, list[tuple[list[float], float]]] = {a: [] for a in protocol["utility_model"]["candidate_arms"]}
    names: list[str] | None = None
    for no_path in _metric_paths(p4_root, profile):
        seed_dir = no_path.parents[2]
        warmup = read_json(seed_dir / "warmup.json")
        spec = read_json(seed_dir / "matrix.json")
        # Local import avoids a circular import and makes the stored matrix auditable.
        from matrix_registry import MatrixSpec
        matrix = MatrixSpec(spec["matrix_id"], spec["analysis_family"], tuple(tuple(tuple(pair) for pair in row) for row in spec["payoff_matrix"]))
        names_here, features = controller_features(matrix, warmup["summary"])
        names = names or names_here
        baseline = float(read_json(no_path)["commit_team_mean_payoff"])
        for arm in rows:
            arm_path = seed_dir / "arms" / arm / "metrics.json"
            if not arm_path.exists(): raise RuntimeError(f"Incomplete P4 trio: {arm_path}")
            delta = float(read_json(arm_path)["commit_team_mean_payoff"]) - baseline
            rows[arm].append((features, delta))
    if not names: raise RuntimeError("No P4 NoAlign metrics found")
    feature_matrix = np.asarray([r[0] for r in next(iter(rows.values()))], dtype=float)
    mean, std = feature_matrix.mean(0), feature_matrix.std(0)
    std[std < 1e-9] = 1.0
    arm_models: dict[str, Any] = {}
    min_rows = int(protocol["utility_model"]["min_train_rows_per_arm"])
    ridge = float(protocol["utility_model"]["ridge_lambda"])
    for arm, arm_rows in rows.items():
        if len(arm_rows) < min_rows: raise RuntimeError(f"{arm} has {len(arm_rows)} rows, need {min_rows}")
        Xraw, y = np.asarray([r[0] for r in arm_rows]), np.asarray([r[1] for r in arm_rows])
        X = np.column_stack([np.ones(len(Xraw)), (Xraw - mean) / std])
        penalty = np.eye(X.shape[1]) * ridge; penalty[0, 0] = 0.0
        gram = X.T @ X + penalty
        inv = np.linalg.pinv(gram)
        beta = inv @ X.T @ y
        resid = y - X @ beta
        df = max(int(len(y) - X.shape[1]), 1)
        arm_models[arm] = ArmModel(beta.tolist(), inv.tolist(), float((resid @ resid) / df), df, len(y)).__dict__
    model = {
        "schema_version": 1, "method": protocol["utility_model"]["method"], "profile": profile,
        "feature_names": names, "feature_mean": mean.tolist(), "feature_std": std.tolist(),
        "arms": arm_models, "ridge_lambda": ridge, "one_sided_z": protocol["utility_model"]["one_sided_z"],
        "p4_rows_per_arm": {a: len(v) for a, v in rows.items()}, "protocol_utility_config": protocol["utility_model"],
    }
    model["model_sha256"] = sha256_value(model)
    return model


def save_model(path: Path, model: dict[str, Any]) -> None:
    write_json(path, model)


def choose_arm(model: dict[str, Any], features: list[float], safety_summary: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    audit: dict[str, Any] = {"safety_pass": bool(safety_summary["safety_pass"]), "candidates": {}}
    if not safety_summary["safety_pass"]:
        audit["reason"] = "safety_certificate_failed"
        return "NoAlign", audit
    xraw = np.asarray(features, dtype=float)
    x = np.concatenate([[1.0], (xraw - np.asarray(model["feature_mean"])) / np.asarray(model["feature_std"])])
    z = float(model["one_sided_z"])
    valid: list[tuple[float, str]] = []
    for arm, raw in model["arms"].items():
        mean, se, lcb = ArmModel(**raw).predict(x, z)
        audit["candidates"][arm] = {"predicted_delta": mean, "predictive_se": se, "lcb": lcb}
        if lcb > 0.0: valid.append((lcb, arm))
    if not valid:
        audit["reason"] = "no_candidate_lcb_above_zero"
        return "NoAlign", audit
    _, selected = max(valid)
    audit["reason"] = "max_positive_lcb"
    return selected, audit
