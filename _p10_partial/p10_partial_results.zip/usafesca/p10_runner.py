#!/usr/bin/env python3
"""P10: registry x presentation x model-pair factorial.

One campaign answers both experiments the reviewer's "shortest path to accept"
asks for:

  * **M4** -- the missing cell.  RQ5 changed the payoff registry *and* the
    presentation at once, so its 0.28 -> 1.00 fidelity jump cannot be attributed.
    P10 crosses the two factors, so the presentation effect is identified within
    a registry and the registry effect within a presentation.
  * **M11** -- a contemporary strong pair.  The same crossed design is run for
    additional model pairs spanning a capability ladder, so "fidelity 0.28 is a
    small-model artifact" becomes a measured main effect with an interaction
    against presentation rather than a rival story nobody tested.

Design invariants (deliberate, and checked):

  * Prompts are produced by ``p7_runner.prompt`` itself, so every P10 arm is
    byte-identical to the archived RQ5 arms.  Re-running RQ3's registry under
    this harness therefore removes the *harness* confound (RQ3 used a different
    runner, max_tokens and episode split) as well as the presentation confound.
  * Warm-up is a NoAlign block, shared by every arm inside a cell -- the same
    common-random-number pairing the paper uses, and the reason the paired
    contrasts in ``p10_analysis`` are as tight as they are.
  * The certificate is evaluated on that warm-up by the shipped
    ``action_safety.summarize_action_safety``; P10 never re-implements it.
  * Action labels can be counterbalanced per cell (``relabel_mode``), because in
    both anti_safe and anti_tradeoff the Eq.(1) target is always the (A,B) cell
    and a positional bias would otherwise sit inside the primary endpoint.

Usage
-----
    python usafesca/p10_runner.py --protocol protocols/p10_factorial_frozen.json \
        --results-root results_p10 --dry-run
    python usafesca/p10_runner.py --protocol protocols/p10_factorial_frozen.json \
        --results-root results_p10 --pair strong_free_a --backend live --workers 4
    python usafesca/p10_runner.py --protocol protocols/p10_factorial_frozen.json \
        --results-root results_p10 --analyze
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np

import p7_runner
from action_safety import summarize_action_safety
from common import immutable_json, read_json, sha256_file, sha256_value, write_json
from matrix_registry import MatrixSpec, recommended_joint_action
from p10_backend import ChatBackend, RateLimitExhausted
from p10_registry import (build_registry, registry_audit, registry_descriptors,
                          registry_sha256, relabel_for, relabel_matrix)

# Presentation label -> the intervention string p7_runner.prompt understands.
# "RoleBound" is resolved from the frozen P7D selection so P10 cannot quietly
# introduce a *third* presentation while claiming to test the RQ5 one.
PRESENTATION_ARMS = {"NoAlign": "NoAlign", "Advisory": "GatedBaseline"}


def stable_seed(*parts: Any) -> int:
    return int.from_bytes(hashlib.sha256("|".join(map(str, parts)).encode()).digest()[:8], "little") % (2 ** 31 - 1)


def as_p7_matrix(spec: MatrixSpec) -> p7_runner.Matrix:
    """Adapter so prompts come from p7_runner verbatim (see tests/test_p10.py)."""
    payoff = tuple(tuple((float(c[0]), float(c[1])) for c in row) for row in spec.payoff_matrix)
    return p7_runner.Matrix(spec.matrix_id, spec.analysis_family, payoff)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Cell enumeration
# ---------------------------------------------------------------------------
def enumerate_cells(protocol: dict[str, Any], pair_ids: list[str] | None = None) -> list[dict[str, Any]]:
    design = protocol["design"]
    pairs = pair_ids or [p["pair_id"] for p in protocol["pairs"] if p.get("enabled", True)]
    cells: list[dict[str, Any]] = []
    for pair_id in pairs:
        for registry_key in design["registries"]:
            reg = build_registry(registry_key, design["families"], design.get("n_per_family"))
            for m in reg:
                for si, seed in enumerate(design["seeds"]):
                    rl = relabel_for(m.matrix_id, seed, si, design.get("relabel_mode", "balanced"))
                    cells.append({"pair_id": pair_id, "registry": registry_key, "matrix_id": m.matrix_id,
                                  "family": m.analysis_family, "seed": int(seed), "seed_index": si,
                                  "relabel": rl.code, "spec": relabel_matrix(m, rl) if rl.code != "00" else m})
    return cells


def budget(protocol: dict[str, Any], pair_ids: list[str] | None = None) -> dict[str, Any]:
    """Exact request counts -- run this *before* spending a free-tier quota."""
    s = protocol["sampling"]
    design = protocol["design"]
    arms = ["NoAlign"] + [a for a in design["presentations"] if a != "NoAlign"]
    per_cell = 2 * s["horizon"] * (s["warmup_episodes"] + s["commit_episodes"] * len(arms))
    cells = enumerate_cells(protocol, pair_ids)
    by_pair: dict[str, Any] = {}
    for pair_cfg in protocol["pairs"]:
        pid = pair_cfg["pair_id"]
        n = len([c for c in cells if c["pair_id"] == pid])
        if not n:
            continue
        calls = n * per_cell
        per_role = calls // 2
        roles = []
        for r in pair_cfg["roles"]:
            lim = r.get("limits", {}) or {}
            rpd, rpm, tpd = lim.get("rpd"), lim.get("rpm"), lim.get("tpd")
            # Elapsed time on a free tier is not requests/rate: you drain a daily
            # cap, then wait for the UTC rollover.  Estimate both walls.
            caps = [c for c in (rpd, (tpd // 260) if tpd else None,
                                (rpm * 1440) if rpm else None) if c]
            daily_cap = min(caps) if caps else None
            if daily_cap:
                full_days = max(0, -(-per_role // daily_cap) - 1)   # ceil - 1
                last = per_role - full_days * daily_cap
                elapsed_h = full_days * 24.0 + (last / rpm / 60.0 if rpm else 0.0)
            else:
                elapsed_h = None
            roles.append({"model": r["model"], "provider": r.get("provider"), "requests": per_role,
                          "free_tier_rpd": rpd, "free_tier_rpm": rpm, "free_tier_tpd": tpd,
                          "effective_daily_cap": daily_cap,
                          "days_of_quota": round(per_role / daily_cap, 2) if daily_cap else None,
                          "elapsed_hours_estimate": round(elapsed_h, 1) if elapsed_h is not None else None})
        walls = [r["elapsed_hours_estimate"] for r in roles if r["elapsed_hours_estimate"] is not None]
        by_pair[pid] = {"cells": n, "requests_per_cell": per_cell, "total_requests": calls,
                        "requests_per_role": per_role, "roles": roles,
                        "elapsed_hours_estimate": round(max(walls), 1) if walls else None,
                        "note": ("roles run concurrently, so the pair's wall clock is the slower role; "
                                 "a role with no quota is GPU-bound and not estimated here")}
    return {"arms": arms, "requests_per_cell": per_cell, "total_cells": len(cells),
            "total_requests": sum(v["total_requests"] for v in by_pair.values()), "by_pair": by_pair}


# ---------------------------------------------------------------------------
# Rollout
# ---------------------------------------------------------------------------
def _role_call(backend: ChatBackend, role: int, m7: Any, history: list[dict[str, Any]], arm: str,
               memory: int, seed: int, ep: int, step: int, presentation: str, target: Any,
               spec: MatrixSpec, context: dict[str, Any], max_parse_retries: int) -> tuple[int, dict[str, Any], int]:
    """One role's full call with retries. Returns (role, out, unparseable_count)."""
    messages = p7_runner.prompt(m7, role, history, arm, memory)
    base = stable_seed(seed, ep, step, role, arm, spec.matrix_id, backend.pair_id)
    out = {"action": None}
    unparseable = 0
    for attempt in range(max_parse_retries + 1):
        out = backend.choose(role, messages, (base + attempt * 7919) % (2 ** 31 - 1),
                             {**context, "presentation": presentation, "episode": ep,
                              "step": step, "role": role, "target": list(target),
                              "matrix_id": spec.matrix_id})
        if out.get("parse_ok"):
            break
        unparseable += 1
    return role, out, unparseable


def rollout(backend: ChatBackend, spec: MatrixSpec, seed: int, presentation: str, arm: str,
            episodes: int, protocol: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    s = protocol["sampling"]
    horizon, memory = s["horizon"], s["memory"]
    max_parse_retries = int(s.get("max_parse_retries", 2))
    m7 = as_p7_matrix(spec)
    target = recommended_joint_action(spec)
    history: list[dict[str, Any]] = []
    eps: list[list[dict[str, Any]]] = []
    unparseable = 0
    truncated = 0
    # The two role prompts within a step are independent (history is read-only
    # until both act), so they are issued concurrently to halve per-step latency.
    # Seeds are role-specific so outputs are byte-identical to the serial version.
    from concurrent.futures import ThreadPoolExecutor as _Pool
    with _Pool(max_workers=2) as pool:
        for ep in range(episodes):
            steps: list[dict[str, Any]] = []
            for step in range(horizon):
                futs = [pool.submit(_role_call, backend, role, m7, history, arm, memory,
                                    seed, ep, step, presentation, target, spec, context, max_parse_retries)
                        for role in range(2)]
                results = {f.result()[0]: f.result() for f in futs}
                acts: list[int | None] = []
                for role in range(2):
                    _, out, unpar = results[role]
                    acts.append(out.get("action"))
                    unparseable += unpar
                if any(a is None for a in acts):
                    truncated += 1
                    break
                a0, a1 = int(acts[0]), int(acts[1])
                rec = {"actions": [a0, a1], "rewards": list(spec.payoff_matrix[a0][a1]),
                       "intervention": arm}
                steps.append(rec)
                history.append(rec)
            if steps:
                eps.append(steps)
    return {"episodes": eps, "unparseable_responses": unparseable, "truncated_episodes": truncated}


def flat(eps: list[list[dict[str, Any]]]) -> list[dict[str, Any]]:
    return [x for e in eps for x in e]


def legacy_certificate(steps: list[dict[str, Any]], cfg: dict[str, Any], seed: int) -> dict[str, Any]:
    """The diagnosed relation-level gate, identical to p7_runner's version."""
    return p7_runner.legacy_certificate(steps, cfg, seed)


def cell_metrics(warm: dict[str, Any], commit: dict[str, Any], spec: MatrixSpec,
                 presentation: str, arm: str, expected_steps: int) -> dict[str, Any]:
    target = recommended_joint_action(spec)
    cm = flat(commit["episodes"])
    wm = flat(warm["episodes"])
    mean = lambda s: float(np.mean([np.mean(x["rewards"]) for x in s])) if s else float("nan")
    joint = [tuple(x["actions"]) == target for x in cm]
    role0 = [x["actions"][0] == target[0] for x in cm]
    role1 = [x["actions"][1] == target[1] for x in cm]
    n_att = expected_steps
    return {
        "presentation": presentation, "prompt_arm": arm,
        "target_cell": list(target),
        # M3 asks which fidelity definition the paper means.  We report both,
        # always, with an explicit denominator.
        "fidelity_joint_profile": float(np.mean(joint)) if joint else float("nan"),
        "fidelity_joint_profile_strict": float(sum(joint) / n_att) if n_att else float("nan"),
        "fidelity_role0_action": float(np.mean(role0)) if role0 else float("nan"),
        "fidelity_role1_action": float(np.mean(role1)) if role1 else float("nan"),
        "fidelity_mean_per_role": float((np.mean(role0) + np.mean(role1)) / 2) if role0 else float("nan"),
        "commit_steps_completed": len(cm), "commit_steps_attempted": n_att,
        "warmup_team_mean_payoff": mean(wm), "commit_team_mean_payoff": mean(cm),
        "commit_minus_warmup_team_mean": (mean(cm) - mean(wm)) if cm and wm else float("nan"),
        "commit_role_means": [float(np.mean([x["rewards"][i] for x in cm])) if cm else float("nan")
                              for i in range(2)],
        "warmup_role_means": [float(np.mean([x["rewards"][i] for x in wm])) if wm else float("nan")
                              for i in range(2)],
        "unparseable_responses": commit["unparseable_responses"],
        "truncated_episodes": commit["truncated_episodes"],
        "test_time_probe_episodes": 0,
    }


def run_cell(protocol: dict[str, Any], root: Path, cell: dict[str, Any], backend: ChatBackend,
             rolebound_arm: str) -> None:
    spec: MatrixSpec = cell["spec"]
    s = protocol["sampling"]
    base = (root / "cells" / cell["pair_id"] / cell["registry"] / cell["matrix_id"] /
            f"rl{cell['relabel']}" / f"seed_{cell['seed']}")
    immutable_json(base / "cell.json", {**{k: v for k, v in cell.items() if k != "spec"},
                                        "payoff_matrix": [[list(c) for c in row] for row in spec.payoff_matrix],
                                        "target_cell": list(recommended_joint_action(spec))})
    ctx = {"pair": cell["pair_id"], "registry": cell["registry"], "matrix_id": cell["matrix_id"],
           "family": cell["family"], "seed": cell["seed"], "relabel": cell["relabel"]}

    warm_path = base / "warmup.json"
    if warm_path.exists():
        warm = read_json(warm_path)
    else:
        warm = rollout(backend, spec, cell["seed"], "NoAlign", "NoAlign",
                       s["warmup_episodes"], protocol, ctx)
        steps = flat(warm["episodes"])
        warm["legacy_summary"] = legacy_certificate(steps, protocol["legacy_safety"],
                                                    stable_seed("legacy", spec.matrix_id, cell["seed"]))
        warm["action_summary"] = summarize_action_safety(steps, spec, protocol["action_safety"],
                                                         stable_seed("action", spec.matrix_id, cell["seed"]))
        warm["payoff_table_visible_to_all_policies"] = True
        immutable_json(warm_path, warm)
        warm = read_json(warm_path)

    arm_map = dict(PRESENTATION_ARMS)
    arm_map["RoleBound"] = rolebound_arm
    expected = s["commit_episodes"] * s["horizon"]
    for presentation in protocol["design"]["presentations"]:
        path = base / "arms" / presentation / "metrics.json"
        if path.exists():
            continue
        arm = arm_map[presentation]
        commit = rollout(backend, spec, cell["seed"], presentation, arm, s["commit_episodes"], protocol, ctx)
        immutable_json(path.parent / "commit_trajectories.json", commit)
        immutable_json(path, cell_metrics(warm, commit, spec, presentation, arm, expected))

    # Derived gate policies: no extra inference, they only re-route the arms
    # already sampled under common random numbers (same convention as p7_runner).
    allow = {"ActionSafeFixed": bool(warm["action_summary"]["safety_pass"]),
             "OldGateFixed": bool(warm["legacy_summary"]["safety_pass"])}
    routed_to = protocol["design"].get("gate_routes_to", "RoleBound")
    for policy, permitted in allow.items():
        path = base / "arms" / policy / "metrics.json"
        if path.exists():
            continue
        src = routed_to if permitted else "NoAlign"
        obj = dict(read_json(base / "arms" / src / "metrics.json"))
        obj.update({"presentation": policy, "counterfactual_source_arm": src,
                    "counterfactual_common_random_numbers": True, "gate_permitted": permitted,
                    "gate_reasons": (warm["action_summary"]["safety_reasons"] if policy == "ActionSafeFixed"
                                     else warm["legacy_summary"]["safety_reasons"])})
        immutable_json(path, obj)


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------
def pilot(protocol: dict[str, Any], root: Path, backend: ChatBackend, rolebound_arm: str,
          n_calls: int) -> dict[str, Any]:
    """Pre-flight on a handful of calls: parse rate, latency, tokens, decode budget.

    Reviewer-facing point: ``max_tokens`` must be large enough that a reasoning
    model reaches its final channel, but it is a harness parameter, so it cannot
    be tuned on the confirmatory data.  The pre-registration fixes it here: run
    this pilot on ONE matrix that is not in any analysed family, take the
    smallest max_tokens in the protocol's ladder that yields a parse-failure rate
    below the threshold, freeze it, and report it.  Nothing from the pilot enters
    the analysis.
    """
    import time
    design = protocol["design"]
    probe_registry = build_registry(design["registries"][0], ["coordination"], 1)
    spec = probe_registry[0]
    m7 = as_p7_matrix(spec)
    target = recommended_joint_action(spec)
    ladder = protocol.get("pilot", {}).get("max_tokens_ladder", [20, 64, 160, 384])
    threshold = float(protocol.get("pilot", {}).get("max_parse_failure_rate", 0.01))
    report: dict[str, Any] = {"probe_matrix": spec.matrix_id, "roles": []}
    for ep in backend.roles:
        chosen = None
        rungs = []
        for mt in ladder:
            ep.max_tokens = int(mt)
            ok = lat = tok = 0
            t0 = time.time()
            for i in range(n_calls):
                messages = p7_runner.prompt(m7, ep.role, [], rolebound_arm, protocol["sampling"]["memory"])
                out = backend.choose(ep.role, messages, 5_000_000 + i,
                                     {"pilot": True, "matrix_id": spec.matrix_id, "target": list(target),
                                      "presentation": "pilot", "registry": design["registries"][0]})
                ok += int(bool(out.get("parse_ok")))
            lat = (time.time() - t0) / max(n_calls, 1)
            rate = 1.0 - ok / max(n_calls, 1)
            rungs.append({"max_tokens": mt, "parse_failure_rate": rate, "seconds_per_call": round(lat, 3)})
            if rate <= threshold:
                chosen = mt
                break
        report["roles"].append({"role": ep.role, "model": ep.model, "provider": ep.provider,
                                "ladder": rungs, "frozen_max_tokens": chosen,
                                "meets_threshold": chosen is not None})
    report["all_roles_ok"] = all(r["meets_threshold"] for r in report["roles"])
    report["next"] = ("paste frozen_max_tokens into the protocol's role entries, then re-run --dry-run"
                      if report["all_roles_ok"] else
                      "no rung met the parse threshold: fix the prompt/parser or drop this pair, and say so")
    write_json(root / "pilot" / f"{backend.pair_id}.json", report)
    return report


def resolve_rolebound_arm(protocol: dict[str, Any], package_root: Path) -> str:
    """Take the role-bound presentation from the frozen P7D selection, not the protocol."""
    cfg = protocol["design"]["rolebound_source"]
    sel_path = package_root / cfg["selection_file"]
    selection = read_json(sel_path)
    if not selection.get("selection_success"):
        raise RuntimeError(f"{sel_path} does not record a successful P7D selection")
    arm = selection["selected_prompt"]
    if arm not in cfg["allowed_prompts"]:
        raise RuntimeError(f"P7D selected {arm!r}, which is not in the P10 allow-list")
    if cfg.get("expected_protocol_sha256") and selection.get("protocol_sha256") != cfg["expected_protocol_sha256"]:
        raise RuntimeError("P7D selection was frozen against a different P7 protocol than P10 expects")
    return arm


def main() -> None:
    ap = argparse.ArgumentParser(description="P10 registry x presentation x pair factorial")
    ap.add_argument("--protocol", type=Path, required=True)
    ap.add_argument("--results-root", type=Path, required=True)
    ap.add_argument("--pair", action="append", default=None, help="restrict to these pair_ids")
    ap.add_argument("--backend", choices=["live", "synthetic"], default="live")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--dry-run", action="store_true", help="print the exact request budget and exit")
    ap.add_argument("--pilot", type=int, default=0, metavar="N",
                    help="pre-flight N calls per role on an unanalysed probe matrix, then exit")
    ap.add_argument("--analyze", action="store_true")
    ap.add_argument("--allow-closed-weights", action="store_true",
                    help="escape hatch; disables the reproducibility guard (not used for the paper)")
    args = ap.parse_args()

    protocol = read_json(args.protocol)
    package_root = args.protocol.resolve().parent.parent
    root = args.results_root.resolve()

    if args.dry_run:
        print(json.dumps(budget(protocol, args.pair), indent=2))
        return
    if args.analyze:
        import p10_analysis
        print(json.dumps(p10_analysis.analyze(protocol, root), indent=2))
        return

    rolebound = resolve_rolebound_arm(protocol, package_root)
    pairs = {p["pair_id"]: p for p in protocol["pairs"] if p.get("enabled", True)}
    selected = args.pair or list(pairs)
    unknown = [p for p in selected if p not in pairs]
    if unknown:
        raise SystemExit(f"unknown/disabled pair ids: {unknown}")

    if args.pilot:
        for pair_id in selected:
            backend = ChatBackend(pairs[pair_id], "synthetic" if args.backend == "synthetic" else "live",
                                  root, require_open_weights=not args.allow_closed_weights)
            print(json.dumps(pilot(protocol, root, backend, rolebound, args.pilot), indent=2))
        return

    # Freeze the design before any inference happens.
    manifest: dict[str, Any] = {"protocol_sha256": sha256_file(args.protocol),
                                "rolebound_arm": rolebound, "registries": {}}
    for key in protocol["design"]["registries"]:
        reg = build_registry(key, protocol["design"]["families"], protocol["design"].get("n_per_family"))
        manifest["registries"][key] = {"sha256": registry_sha256(reg), "matrices": registry_audit(reg),
                                       "descriptors": registry_descriptors(reg)}
    manifest["design_sha256"] = sha256_value({k: v for k, v in protocol["design"].items()})
    immutable_json(root / "P10_MANIFEST.json", manifest)

    for pair_id in selected:
        cfg = pairs[pair_id]
        backend = ChatBackend(cfg, "synthetic" if args.backend == "synthetic" else "live", root,
                              require_open_weights=not args.allow_closed_weights)
        write_json(root / "provenance" / f"{pair_id}.json", backend.provenance())
        cells = enumerate_cells(protocol, [pair_id])
        parked: list[str] = []
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            futures = {ex.submit(run_cell, protocol, root, c, backend, rolebound): c for c in cells}
            for fut in as_completed(futures):
                try:
                    fut.result()
                except RateLimitExhausted as exc:
                    parked.append(str(exc))
                    for other in futures:
                        other.cancel()
                except Exception as exc:  # keep the campaign resumable
                    c = futures[fut]
                    print(f"[cell failed] {c['pair_id']}/{c['registry']}/{c['matrix_id']}/seed_{c['seed']}: {exc}",
                          file=sys.stderr)
        write_json(root / "provenance" / f"{pair_id}_stats.json",
                   {"stats": backend.stats, "parked": sorted(set(parked)), "cells": len(cells)})
        if parked:
            print(json.dumps({"pair": pair_id, "status": "parked_on_free_tier_quota",
                              "detail": sorted(set(parked)),
                              "action": "re-run the same command after the UTC day rolls over; "
                                        "completed cells are skipped"}, indent=2))
        else:
            print(json.dumps({"pair": pair_id, "status": "complete", "cells": len(cells),
                              "stats": backend.stats}, indent=2))


if __name__ == "__main__":
    main()
