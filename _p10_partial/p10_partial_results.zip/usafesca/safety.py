"""Trajectory-only coverage certificate used by LegacySafeSCA and U-SafeSCA."""
from __future__ import annotations

from typing import Any, Iterable

import numpy as np


def summarize_warmup(steps: Iterable[dict[str, Any]], safety: dict[str, Any], bootstrap_seed: int) -> dict[str, Any]:
    observations = list(steps)
    same = [float(np.mean(step["rewards"])) for step in observations if step["actions"][0] == step["actions"][1]]
    different = [float(np.mean(step["rewards"])) for step in observations if step["actions"][0] != step["actions"][1]]
    profiles = {tuple(int(a) for a in step["actions"]) for step in observations}
    split = None
    upper = None
    if same and different:
        split = float(np.mean(different) - np.mean(same))
        rng = np.random.default_rng(bootstrap_seed)
        a, b = np.asarray(same), np.asarray(different)
        draws = int(safety["bootstrap_samples"])
        boot = rng.choice(b, size=(draws, len(b)), replace=True).mean(1) - rng.choice(a, size=(draws, len(a)), replace=True).mean(1)
        upper = float(np.quantile(boot, safety["confidence"]))
    actions = [a for step in observations for a in step["actions"]]
    probs = np.bincount(actions, minlength=2) / max(len(actions), 1)
    entropy = float(-sum(p * np.log(p) for p in probs if p > 0))
    reasons: list[str] = []
    if len(same) < int(safety["min_same_observations"]): reasons.append("insufficient_same_observations")
    if len(different) < int(safety["min_different_observations"]): reasons.append("insufficient_different_observations")
    if len(profiles) / 4.0 < float(safety["min_profile_coverage"]): reasons.append("insufficient_profile_coverage")
    if upper is None: reasons.append("split_confidence_unavailable")
    elif upper >= -float(safety["tau"]): reasons.append("coordination_not_certified")
    return {
        "n_observations": len(observations), "n_same": len(same), "n_different": len(different),
        "same_mean": float(np.mean(same)) if same else 0.0, "different_mean": float(np.mean(different)) if different else 0.0,
        "n_unique_profiles": len(profiles), "n_possible_profiles": 4, "profile_coverage": len(profiles) / 4.0,
        "split_score": split, "split_upper_bound": upper, "action_entropy": entropy,
        "safety_pass": not reasons, "safety_reasons": reasons,
    }
