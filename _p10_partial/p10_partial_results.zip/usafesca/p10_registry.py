"""P10 registries: one interface over the two payoff registries the paper
already used, plus the action-relabelling machinery the factorial needs.

Why this module exists
----------------------
Reviewer M4 asks us to separate two things that moved together between RQ3 and
RQ5: the *payoff registry* and the *presentation*.  To vary the registry as a
factor we need both registries reachable from one runner, generated bit-exactly
as their original campaigns generated them:

  * generator "p6r"  -- ``p6_registry.build_p6_registry`` with the id prefix
                        rewritten to ``p6r_`` (this is literally RQ3's registry,
                        seed 260902, n_per_family 4);
  * generator "p7"   -- the inline sampler in ``p7_runner.registry`` (RQ5's
                        registry, seed 270702, n_per_family 4).

They are *different samplers*, not just different seeds, so "registry" as a
factor bundles seed + generator.  That is exactly the bundle the paper's
0.28 -> 1.00 comparison confounds with presentation, so it is the right unit to
manipulate.  ``registry_descriptors`` below quantifies how the two differ, at
zero GPU cost, so "the new registry was simply easier" becomes a measurable
claim rather than a rhetorical one.

Action relabelling
------------------
In both anti_safe and anti_tradeoff the Eq.(1) target is *always* the (A,B)
cell, for every matrix in both registries.  A pair with a positional bias
towards the first-listed action therefore has its joint target fidelity
determined partly by that bias -- and supplement H already discloses that a
position-bias fix was needed during development.  Since fidelity is the primary
endpoint of the P10 campaign, we cannot leave that free.  ``relabel`` permutes
each role's action labels; the game is unchanged up to relabelling, the
certificate's verdict is invariant (asserted in tests/test_p10.py), and the
target cell is moved around the matrix in a balanced, pre-registered way.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np

from common import sha256_value
from matrix_registry import MatrixSpec, recommended_joint_action
from p6_registry import build_p6_registry


P10_FAMILIES = ("anti_safe", "anti_tradeoff", "coordination", "mixed")

# The two registries the paper's confounded comparison spans, plus a pooled
# variant of each.  Frozen here so a protocol can only *name* a registry, never
# redefine one.
#
# Why the pooled variants exist: supplement D's own power rule asks for
# nmat >= 24 per family before a result may be called confirmatory, and reviewer
# M4 holds the paper to it.  Both original registries were frozen at 4 matrices
# per family, and we may not enlarge them in place -- changing n changes the RNG
# stream and therefore every matrix.  So each pooled registry is the *original
# four* (kept bit-exact, for direct comparability with the archived campaigns)
# plus 20 fresh matrices drawn from the identical generator under a separate,
# pre-registered seed.  The estimand is defined over the generator's
# distribution, so pooling is legitimate; the legacy subset stays identifiable
# by its matrix-id prefix and is reported separately.
REGISTRY_SPECS: dict[str, dict[str, Any]] = {
    "R_rq3": {
        "generator": "p6r",
        "seed": 260902,
        "n_per_family": 4,
        "prefix": "p6r",
        "provenance": "RQ3 cross-pair registry (protocols/p6r_cross_pair_frozen.json)",
    },
    "R_rq5": {
        "generator": "p7",
        "seed": 270702,
        "n_per_family": 4,
        "prefix": "p7",
        "provenance": "RQ5 confirmatory registry (protocols/p7_rolebound_frozen.json, phase p7)",
    },
    "R_rq3_pooled": {
        "generator": "p6r",
        "seed": 260902,
        "n_per_family": 4,
        "prefix": "p6r",
        "extension": {"seed": 2609021, "n_per_family": 20, "prefix": "p6rx"},
        "provenance": "RQ3 registry (4/family, bit-exact) + 20/family fresh draws from the same sampler",
    },
    "R_rq5_pooled": {
        "generator": "p7",
        "seed": 270702,
        "n_per_family": 4,
        "prefix": "p7",
        "extension": {"seed": 2707021, "n_per_family": 20, "prefix": "p7x"},
        "provenance": "RQ5 registry (4/family, bit-exact) + 20/family fresh draws from the same sampler",
    },
}

# Which registry each key stands in for, when a decision rule needs to know
# "this is the one RQ3 ran on".
REGISTRY_ROLE = {"R_rq3": "rq3", "R_rq3_pooled": "rq3", "R_rq5": "rq5", "R_rq5_pooled": "rq5"}


def _p7_matrices(seed: int, n_per_family: int, families: Iterable[str], prefix: str) -> list[MatrixSpec]:
    """Bit-exact reproduction of ``p7_runner.registry``.

    The draw order there is family-major, ``rng.uniform(-.18,.18,8)`` per matrix,
    so we must consume the generator in the same order to land on the same
    matrices.  ``tests/test_p10.py`` asserts equality against p7_runner itself.
    """
    rng = np.random.default_rng(seed)
    out: list[MatrixSpec] = []
    for family in families:
        for k in range(1, n_per_family + 1):
            eps = rng.uniform(-.18, .18, 8)
            if family == "anti_safe":
                p = (((.45 + eps[0], .45 + eps[1]), (4.35 + eps[2], 4.05 + eps[3])),
                     ((1.15 + eps[4], 1.15 + eps[5]), (.20 + eps[6], .25 + eps[7])))
            elif family == "anti_tradeoff":
                p = (((.90 + eps[0], .88 + eps[1]), (-.02 + eps[2], 4.98 + eps[3])),
                     ((.18 + eps[4], .20 + eps[5]), (-.12 + eps[6], -.08 + eps[7])))
            elif family == "coordination":
                p = (((4.15 + eps[0], 4.05 + eps[1]), (.15 + eps[2], .95 + eps[3])),
                     ((.95 + eps[4], .15 + eps[5]), (3.20 + eps[6], 3.10 + eps[7])))
            elif family == "mixed":
                p = (((2.10 + eps[0], 2.15 + eps[1]), (2.25 + eps[2], 2.20 + eps[3])),
                     ((2.20 + eps[4], 2.10 + eps[5]), (2.25 + eps[6], 2.20 + eps[7])))
            else:
                raise ValueError(family)
            payoff = tuple(tuple((float(c[0]), float(c[1])) for c in row) for row in p)
            out.append(MatrixSpec(f"{prefix}_{family}_{k:02d}", family, payoff))
    return out


def _draw(generator: str, seed: int, n_per_family: int, prefix: str) -> list[MatrixSpec]:
    """One block of matrices.  Always drawn over ALL four families in canonical
    order, then filtered by the caller, so that dropping a family can never shift
    the RNG stream of the families we keep."""
    if generator == "p6r":
        source = build_p6_registry(seed, n_per_family)
        return [MatrixSpec(x.matrix_id.replace("p6_", prefix + "_", 1), x.analysis_family, x.payoff_matrix)
                for x in source]
    if generator == "p7":
        return _p7_matrices(seed, n_per_family, P10_FAMILIES, prefix)
    raise ValueError(f"unknown generator {generator!r}")  # pragma: no cover


def build_registry(registry_key: str, families: Iterable[str] | None = None,
                   n_per_family: int | None = None) -> list[MatrixSpec]:
    """Return the named registry, restricted to ``families`` in P10_FAMILIES order.

    ``n_per_family`` may only *shrink* the legacy block (for a screening tier);
    it can never grow it, because a larger n changes the draw sequence and would
    silently replace the matrices the archived campaigns actually ran.
    """
    if registry_key not in REGISTRY_SPECS:
        raise KeyError(f"unknown registry {registry_key!r}; known: {sorted(REGISTRY_SPECS)}")
    spec = REGISTRY_SPECS[registry_key]
    fams = tuple(families) if families is not None else P10_FAMILIES
    unknown = [f for f in fams if f not in P10_FAMILIES]
    if unknown:
        raise ValueError(f"unknown families {unknown}")
    n = int(n_per_family if n_per_family is not None else spec["n_per_family"])
    if n > spec["n_per_family"]:
        raise ValueError(
            f"{registry_key} was frozen at n_per_family={spec['n_per_family']}; "
            "requesting more would change every matrix in it -- use a *_pooled registry instead")
    blocks = [(_draw(spec["generator"], spec["seed"], spec["n_per_family"], spec["prefix"]), n)]
    ext = spec.get("extension")
    if ext:
        blocks.append((_draw(spec["generator"], ext["seed"], ext["n_per_family"], ext["prefix"]),
                       ext["n_per_family"]))
    keep: list[MatrixSpec] = []
    for family in fams:
        for block, take in blocks:
            keep.extend([m for m in block if m.analysis_family == family][:take])
    return keep


def legacy_subset(registry: list[MatrixSpec], registry_key: str) -> list[str]:
    """Matrix ids in ``registry`` that are bit-identical to the archived campaign."""
    prefix = REGISTRY_SPECS[registry_key]["prefix"] + "_"
    return [m.matrix_id for m in registry if m.matrix_id.startswith(prefix)]


# ---------------------------------------------------------------------------
# Action relabelling
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Relabel:
    """Per-role action permutation.  For |A| = 2 a permutation is a swap flag."""
    swap_row: bool
    swap_col: bool

    @property
    def code(self) -> str:
        return f"{int(self.swap_row)}{int(self.swap_col)}"


RELABELS = (Relabel(False, False), Relabel(False, True), Relabel(True, False), Relabel(True, True))


def relabel_matrix(spec: MatrixSpec, rl: Relabel) -> MatrixSpec:
    """Return the same game with each role's action labels permuted.

    Only the *names* of actions change: the game, its equilibria, its Pareto
    frontier and every quantity the certificate reads are carried along.  The id
    records the permutation so artifacts stay self-describing.
    """
    p = spec.payoff_matrix
    ridx = [1, 0] if rl.swap_row else [0, 1]
    cidx = [1, 0] if rl.swap_col else [0, 1]
    payoff = tuple(tuple((float(p[ridx[i]][cidx[j]][0]), float(p[ridx[i]][cidx[j]][1]))
                         for j in range(2)) for i in range(2))
    return MatrixSpec(f"{spec.matrix_id}#rl{rl.code}", spec.analysis_family, payoff)


def relabel_for(matrix_id: str, seed: int, seed_index: int, mode: str) -> Relabel:
    """Pre-registered assignment of a permutation to a (matrix, seed) cell.

    mode = "identity"  : no relabelling (reproduces the archived campaigns);
    mode = "balanced"  : cycle the four permutations by seed rank, so with a
                         seed count divisible by 4 every matrix sees each
                         permutation equally often -- a within-matrix
                         counterbalance against positional bias;
    mode = "hashed"    : deterministic pseudo-random assignment (used only for
                         robustness re-analysis, never for the primary endpoint).
    """
    if mode == "identity":
        return RELABELS[0]
    if mode == "balanced":
        return RELABELS[seed_index % 4]
    if mode == "hashed":
        h = hashlib.sha256(f"p10-relabel|{matrix_id}|{seed}".encode()).digest()
        return RELABELS[h[0] % 4]
    raise ValueError(f"unknown relabel mode {mode!r}")


# ---------------------------------------------------------------------------
# Registry difficulty descriptors (0 GPU) -- makes "the new registry was easier"
# a measurable claim.
# ---------------------------------------------------------------------------
def matrix_descriptor(spec: MatrixSpec) -> dict[str, Any]:
    p = spec.payoff_matrix
    target = recommended_joint_action(spec)
    tr = (float(p[target[0]][target[1]][0]), float(p[target[0]][target[1]][1]))
    scores = {(i, j): (p[i][j][0] + p[i][j][1]) / 2.0 - 0.25 * abs(p[i][j][0] - p[i][j][1])
              for i in range(2) for j in range(2)}
    best = scores[target]
    runner_up = max(v for k, v in scores.items() if k != target)
    dev_row = max(float(p[a][target[1]][0]) for a in range(2)) - tr[0]
    dev_col = max(float(p[target[0]][a][1]) for a in range(2)) - tr[1]
    diag = [(p[0][0][0] + p[0][0][1]) / 2.0, (p[1][1][0] + p[1][1][1]) / 2.0]
    return {
        "matrix_id": spec.matrix_id,
        "analysis_family": spec.analysis_family,
        "target_cell": list(target),
        "target_is_diagonal": bool(target[0] == target[1]),
        "target_rewards": list(tr),
        "target_team_mean": (tr[0] + tr[1]) / 2.0,
        "target_inequity": abs(tr[0] - tr[1]),
        "target_min_role_reward": min(tr),
        "eq1_score_margin_over_runner_up": float(best - runner_up),
        "max_unilateral_deviation_gain": float(max(dev_row, dev_col)),
        "target_is_strict_pure_nash": bool(max(dev_row, dev_col) < 0.0),
        "best_diagonal_team_mean": float(max(diag)),
        # A crude but honest "how much does a coordinating-but-unadvised pair
        # already get?" proxy: the best cell reachable by both playing the same
        # label.  The larger this is relative to the target, the less headroom an
        # advisory has -- and the easier the registry looks without any advice.
        "target_minus_best_diagonal": float((tr[0] + tr[1]) / 2.0 - max(diag)),
    }


def registry_descriptors(registry: list[MatrixSpec]) -> dict[str, Any]:
    rows = [matrix_descriptor(m) for m in registry]
    out: dict[str, Any] = {"n_matrices": len(rows), "per_matrix": rows, "by_family": {}}
    for family in sorted({r["analysis_family"] for r in rows}):
        fam = [r for r in rows if r["analysis_family"] == family]
        agg = {}
        for key in ("target_team_mean", "target_min_role_reward", "eq1_score_margin_over_runner_up",
                    "max_unilateral_deviation_gain", "best_diagonal_team_mean", "target_minus_best_diagonal",
                    "target_inequity"):
            agg[key] = float(np.mean([r[key] for r in fam]))
        agg["frac_target_diagonal"] = float(np.mean([r["target_is_diagonal"] for r in fam]))
        agg["frac_target_strict_nash"] = float(np.mean([r["target_is_strict_pure_nash"] for r in fam]))
        agg["n_matrices"] = len(fam)
        out["by_family"][family] = agg
    return out


def registry_audit(registry: list[MatrixSpec]) -> list[dict[str, Any]]:
    return [m.audit_dict() for m in registry]


def registry_sha256(registry: list[MatrixSpec]) -> str:
    return sha256_value(registry_audit(registry))


__all__ = [
    "P10_FAMILIES", "REGISTRY_SPECS", "REGISTRY_ROLE", "build_registry", "legacy_subset",
    "Relabel", "RELABELS", "relabel_matrix", "relabel_for", "matrix_descriptor",
    "registry_descriptors", "registry_audit", "registry_sha256",
]
