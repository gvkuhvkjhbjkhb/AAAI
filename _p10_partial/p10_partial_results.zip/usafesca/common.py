"""Small immutable-artifact helpers shared by the P4/P5 implementation."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_value(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def immutable_json(path: Path, value: Any) -> None:
    """Create an artifact once; identical reruns are allowed, mutations are not."""
    payload = json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != payload:
            raise RuntimeError(f"Refusing to overwrite immutable artifact: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8")


def load_protocol(path: Path) -> dict[str, Any]:
    protocol = read_json(path)
    if protocol.get("campaign") == "p6r_cross_pair_gate_mechanism_v1":
        required = {"schema_version", "campaign", "model_pair", "p6r", "sampling", "legacy_safety", "action_safety", "utility_model", "analysis", "execution"}
        missing = sorted(required - set(protocol))
        if missing: raise ValueError(f"P6R protocol is missing keys: {missing}")
        if protocol["model_pair"].get("revision_lock_required") is not True: raise ValueError("P6R requires a revision lock")
        if protocol["utility_model"]["test_time_probe_episodes"] != 0: raise ValueError("P6R must never use online probe episodes")
        if protocol["p6r"]["policies"][:2] != ["NoAlign", "Gated"]: raise ValueError("P6R needs NoAlign and Gated fixed arms")
        return protocol
    if protocol.get("campaign") == "u_safesca_p6_action_aware_v1":
        required = {"schema_version", "campaign", "p4_frozen_utility_model_sha256", "p6", "sampling", "legacy_safety", "action_safety", "utility_model", "analysis", "execution"}
        missing = sorted(required - set(protocol))
        if missing: raise ValueError(f"P6 protocol is missing keys: {missing}")
        if protocol["sampling"]["warmup_episodes"] <= 0 or protocol["sampling"]["total_episodes"] <= protocol["sampling"]["warmup_episodes"]:
            raise ValueError("P6 requires a positive warm-up shorter than the total horizon")
        if protocol["utility_model"]["test_time_probe_episodes"] != 0: raise ValueError("P6 must never use online probe episodes")
        if set(["NoAlign", "SoftGated", "Gated"]) - set(protocol["p6"]["policies"]): raise ValueError("P6 requires the three fixed arms")
        return protocol
    required = {"schema_version", "campaign", "p4", "p5", "sampling", "safety", "utility_model", "analysis", "execution"}
    missing = sorted(required - set(protocol))
    if missing:
        raise ValueError(f"Protocol is missing keys: {missing}")
    if protocol["campaign"] != "u_safesca_p4p5_v1":
        raise ValueError("Unexpected campaign")
    if protocol["sampling"]["warmup_episodes"] <= 0:
        raise ValueError("warmup_episodes must be positive")
    if protocol["sampling"]["total_episodes"] <= protocol["sampling"]["warmup_episodes"]:
        raise ValueError("total_episodes must exceed warmup_episodes")
    if protocol["utility_model"]["test_time_probe_episodes"] != 0:
        raise ValueError("P5 must never use online probe episodes")
    if protocol["p4"]["policies"] != ["NoAlign", "SoftGated", "Gated"]:
        raise ValueError("P4 must contain exactly the three fixed arms")
    if "USafeSCA" not in protocol["p5"]["policies"]:
        raise ValueError("P5 must contain USafeSCA")
    return protocol


def package_root_from_code() -> Path:
    return Path(__file__).resolve().parents[1]
