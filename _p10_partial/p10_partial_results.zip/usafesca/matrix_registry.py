"""Deterministic, category-hidden P4/P5 registries for 2x2 matrix games.

The category is analysis metadata.  The agent prompt and the U-SafeSCA
controller receive the canonical payoff table, never the category or matrix id.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from common import sha256_value


FAMILIES = ("coordination", "anti", "boundary", "mixed")


@dataclass(frozen=True)
class MatrixSpec:
    matrix_id: str
    analysis_family: str
    payoff_matrix: tuple[tuple[tuple[float, float], tuple[float, float]], tuple[tuple[float, float], tuple[float, float]]]

    def audit_dict(self) -> dict[str, Any]:
        raw = asdict(self)
        raw["payoff_matrix"] = [[list(pair) for pair in row] for row in self.payoff_matrix]
        return raw


def _pair(a: float, b: float) -> tuple[float, float]:
    return (round(float(a), 2), round(float(b), 2))


def _make_matrix(family: str, rng: np.random.Generator) -> tuple[tuple[tuple[float, float], tuple[float, float]], tuple[tuple[float, float], tuple[float, float]]]:
    """Generate varied but bounded social-dilemma surfaces without using game names."""
    j = lambda scale=0.35: rng.uniform(-scale, scale)
    if family == "coordination":
        # Two cooperative diagonals, with a random focal point and asymmetric off-diagonal penalties.
        aa, bb = 4.3 + j(), 3.2 + j()
        ab, ba = 0.2 + j(), 0.1 + j()
        return ((_pair(aa, aa + j(0.2)), _pair(ab, 1.0 + j())),
                (_pair(1.0 + j(), ba), _pair(bb + j(0.2), bb)))
    if family == "anti":
        # Differentiated actions produce the team optimum; diagonals are weak or adverse.
        aa, bb = 0.6 + j(), 0.3 + j()
        ab1, ab2 = 1.0 + j(), 4.7 + j()
        ba1, ba2 = 4.7 + j(), 1.0 + j()
        return ((_pair(aa, aa + j(0.2)), _pair(ab1, ab2)),
                (_pair(ba1, ba2), _pair(bb, bb + j(0.2))))
    if family == "boundary":
        # One diagonal is good, yet unilateral temptation makes intervention uncertain.
        aa, bb = 3.9 + j(), 2.2 + j()
        return ((_pair(aa, aa + j(0.4)), _pair(-0.2 + j(), 2.8 + j())),
                (_pair(2.8 + j(), -0.2 + j()), _pair(bb + j(0.4), bb)))
    if family == "mixed":
        # Near-flat team surface: a conservative utility LCB should often abstain.
        base = 2.2 + j(0.15)
        return ((_pair(base + j(0.22), base + j(0.22)), _pair(base + j(0.22), base + j(0.22))),
                (_pair(base + j(0.22), base + j(0.22)), _pair(base + j(0.22), base + j(0.22))))
    raise ValueError(f"Unknown family: {family}")


def build_registry(phase: str, seed: int, n_per_family: int) -> list[MatrixSpec]:
    if phase not in {"p4", "p5"} or n_per_family < 1:
        raise ValueError("Invalid phase or n_per_family")
    rng = np.random.default_rng(seed)
    registry: list[MatrixSpec] = []
    for family in FAMILIES:
        for index in range(1, n_per_family + 1):
            registry.append(MatrixSpec(f"{phase}_{family}_{index:02d}", family, _make_matrix(family, rng)))
    return registry


def registry_audit(registry: list[MatrixSpec]) -> list[dict[str, Any]]:
    return [spec.audit_dict() for spec in registry]


def registry_sha256(registry: list[MatrixSpec]) -> str:
    return sha256_value(registry_audit(registry))


def controller_features(spec: MatrixSpec, warmup: dict[str, Any]) -> tuple[list[str], list[float]]:
    """Only payoff-table values and warm-up observations are allowed features."""
    p = spec.payoff_matrix
    team = np.asarray([sum(p[i][j]) / 2.0 for i in range(2) for j in range(2)], dtype=float)
    inequity = np.asarray([abs(p[i][j][0] - p[i][j][1]) for i in range(2) for j in range(2)], dtype=float)
    diag, off = np.asarray([team[0], team[3]]), np.asarray([team[1], team[2]])
    names = [
        "team_mean", "team_range", "team_max", "team_min", "diag_mean", "offdiag_mean",
        "diag_minus_offdiag", "best_diag_minus_best_offdiag", "mean_inequity",
        "warmup_split", "warmup_split_upper", "warmup_coverage", "warmup_same_mean",
        "warmup_different_mean", "warmup_action_entropy",
    ]
    split = warmup.get("split_score")
    upper = warmup.get("split_upper_bound")
    values = [
        float(team.mean()), float(team.max() - team.min()), float(team.max()), float(team.min()),
        float(diag.mean()), float(off.mean()), float(diag.mean() - off.mean()),
        float(diag.max() - off.max()), float(inequity.mean()),
        0.0 if split is None else float(split), 0.0 if upper is None else float(upper),
        float(warmup["profile_coverage"]), float(warmup.get("same_mean", 0.0)),
        float(warmup.get("different_mean", 0.0)), float(warmup.get("action_entropy", 0.0)),
    ]
    return names, values


def recommended_joint_action(spec: MatrixSpec) -> tuple[int, int]:
    """A transparent shared recommendation; agents retain their own final action."""
    candidates: list[tuple[float, int, int]] = []
    for row in range(2):
        for col in range(2):
            u0, u1 = spec.payoff_matrix[row][col]
            # Equal-weight team reward with a small inequity penalty, fixed before P4.
            candidates.append(((u0 + u1) / 2.0 - 0.25 * abs(u0 - u1), row, col))
    _, row, col = max(candidates)
    return row, col
