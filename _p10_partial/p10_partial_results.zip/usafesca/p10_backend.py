"""Backends for the P10 factorial campaign.

The campaign has to run a *contemporary, strong* model pair (reviewer M11) under
two constraints the earlier campaigns never faced:

  1. the pair must be obtainable **free and fast** -- no GPU rental, no waiting
     list, no credit card;
  2. the paper's reproducibility claim (its strongest score) must survive.

Those two pull in opposite directions unless the strong models are *open
weights served on a free hosted endpoint*.  Then the authors get a same-day run
through the hosted endpoint, and any reviewer can re-serve the identical weights
with vLLM at a pinned Hugging Face revision and re-run the campaign offline.  A
closed frontier API would buy strength at the cost of the one thing this paper
is best at, so `require_open_weights` below is enforced, not advisory.

What this module provides
-------------------------
* ``ChatBackend`` -- one OpenAI-compatible client that talks to vLLM, Groq,
  Cerebras, OpenRouter, Google's OpenAI-compat endpoint, or anything else with
  a ``/chat/completions`` route, plus a fully deterministic ``synthetic`` mode
  for CI.
* A **free-tier governor**: per-role token buckets for requests/min and
  tokens/min, and a *persistent* requests/day and tokens/day ledger on disk, so
  a campaign that hits a daily cap parks itself and resumes the next UTC day
  without losing work or silently dropping cells.
* **Honest parse accounting.**  Fidelity is the primary endpoint of this
  campaign, so a response we cannot parse must never be quietly re-rolled into a
  "non-target" step or dropped.  Every failure is recorded with its raw text and
  surfaces in the analysis integrity block.
* **Provenance capture**: model string echoed by the server, ``system_fingerprint``,
  response ids and provider headers, appended to a per-role JSONL log.
"""
from __future__ import annotations

import json
import os
import random
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib import error as urlerror
from urllib import request as urlrequest

import numpy as np


class RateLimitExhausted(RuntimeError):
    """Raised when a per-day free-tier quota is spent; the runner parks."""


class UnparseableResponse(RuntimeError):
    def __init__(self, text: str, reason: str) -> None:
        super().__init__(f"{reason}: {text!r}")
        self.text, self.reason = text, reason


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------
_THINK = re.compile(r"<think>.*?</think>|<\|channel\|>analysis.*?(?=<\|channel\|>final|$)", re.S | re.I)
_FINAL = re.compile(r"<\|channel\|>final\s*<?\|?message\|?>?", re.I)


def strip_reasoning(text: str) -> str:
    """Remove reasoning-model scaffolding before parsing an action.

    gpt-oss-style models emit an analysis channel; some servers pass it through
    verbatim.  We drop it rather than let a stray 'A' inside the reasoning decide
    the action -- that would be a measurement artifact in the endpoint itself.
    """
    if not text:
        return ""
    out = _THINK.sub(" ", text)
    parts = _FINAL.split(out)
    return parts[-1] if len(parts) > 1 else out


def parse_action(text: str) -> int:
    """Strict-then-lenient action parser.  Raises ``UnparseableResponse``.

    Deliberately identical in behaviour to ``p7_runner.parse_action`` on every
    string that parser accepts (asserted in tests/test_p10.py), so the P10 arms
    remain comparable with the archived campaigns; it only adds the reasoning
    strip in front, which is a no-op for non-reasoning models.
    """
    cleaned = strip_reasoning(text or "")
    if not cleaned.strip():
        raise UnparseableResponse(text or "", "empty_response")
    upper = cleaned.upper()
    for token, val in (("ACTION: A", 0), ("ACTION:A", 0), ("ACTION: B", 1), ("ACTION:B", 1)):
        if token in upper:
            return val
    m = re.search(r"(?i)self\s*:?\s*(a|b)", upper)
    if m:
        return 0 if m.group(1) == "A" else 1
    m2 = re.search(r"(?i)\b(a|b)\b", upper)
    if m2:
        return 0 if m2.group(1) == "A" else 1
    stripped = upper.strip().replace(".", "")
    if stripped in {"A", "0"}:
        return 0
    if stripped in {"B", "1"}:
        return 1
    raise UnparseableResponse(text or "", "no_action_token")


# ---------------------------------------------------------------------------
# Free-tier governor
# ---------------------------------------------------------------------------
@dataclass
class Limits:
    rpm: float | None = None
    tpm: float | None = None
    rpd: int | None = None
    tpd: int | None = None
    max_concurrency: int = 4

    @classmethod
    def from_dict(cls, d: dict[str, Any] | None) -> "Limits":
        d = d or {}
        return cls(rpm=d.get("rpm"), tpm=d.get("tpm"), rpd=d.get("rpd"),
                   tpd=d.get("tpd"), max_concurrency=int(d.get("max_concurrency", 4)))


@dataclass
class Ledger:
    """Persistent per-UTC-day usage counter for one role endpoint."""
    path: Path
    key: str
    day: str = ""
    requests: int = 0
    tokens: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def __post_init__(self) -> None:
        self.day = self.day or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self.path.exists():
            try:
                blob = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                blob = {}
            if blob.get("day") == self.day and blob.get("key") == self.key:
                self.requests, self.tokens = int(blob.get("requests", 0)), int(blob.get("tokens", 0))

    def _flush(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"key": self.key, "day": self.day, "requests": self.requests,
                                   "tokens": self.tokens}, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def roll_if_new_day(self) -> None:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if today != self.day:
            self.day, self.requests, self.tokens = today, 0, 0
            self._flush()

    def charge(self, tokens: int) -> None:
        with self._lock:
            self.roll_if_new_day()
            self.requests += 1
            self.tokens += int(tokens)
            self._flush()

    def check(self, limits: Limits) -> None:
        with self._lock:
            self.roll_if_new_day()
            if limits.rpd is not None and self.requests >= limits.rpd:
                raise RateLimitExhausted(f"{self.key}: daily request cap {limits.rpd} reached on {self.day}")
            if limits.tpd is not None and self.tokens >= limits.tpd:
                raise RateLimitExhausted(f"{self.key}: daily token cap {limits.tpd} reached on {self.day}")


class Governor:
    """Blocking token buckets for RPM/TPM plus the persistent daily ledger."""

    def __init__(self, key: str, limits: Limits, ledger_dir: Path) -> None:
        self.key, self.limits = key, limits
        self.ledger = Ledger(ledger_dir / f"{key}.json", key)
        self._lock = threading.Lock()
        self._req_times: list[float] = []
        self._tok_events: list[tuple[float, int]] = []
        self._sem = threading.Semaphore(max(1, limits.max_concurrency))

    def _prune(self, now: float) -> None:
        self._req_times = [t for t in self._req_times if now - t < 60.0]
        self._tok_events = [(t, n) for t, n in self._tok_events if now - t < 60.0]

    def acquire(self, est_tokens: int) -> None:
        self.ledger.check(self.limits)
        self._sem.acquire()
        try:
            while True:
                with self._lock:
                    now = time.monotonic()
                    self._prune(now)
                    wait = 0.0
                    if self.limits.rpm is not None and len(self._req_times) >= self.limits.rpm:
                        wait = max(wait, 60.0 - (now - self._req_times[0]) + 0.01)
                    if self.limits.tpm is not None:
                        used = sum(n for _, n in self._tok_events)
                        if used + est_tokens > self.limits.tpm and self._tok_events:
                            wait = max(wait, 60.0 - (now - self._tok_events[0][0]) + 0.01)
                    if wait <= 0.0:
                        self._req_times.append(now)
                        self._tok_events.append((now, est_tokens))
                        return
                time.sleep(min(wait, 5.0))
        except BaseException:
            self._sem.release()
            raise

    def release(self, actual_tokens: int) -> None:
        self.ledger.charge(actual_tokens)
        self._sem.release()


# ---------------------------------------------------------------------------
# Roles and backend
# ---------------------------------------------------------------------------
@dataclass
class RoleEndpoint:
    role: int
    provider: str
    model: str
    base_url: str
    api_key_env: str
    limits: Limits
    open_weights: bool
    hf_repo: str | None = None
    hf_revision: str | None = None
    extra_body: dict[str, Any] = field(default_factory=dict)
    max_tokens: int = 20
    timeout_s: float = 120.0

    @property
    def key(self) -> str:
        safe = re.sub(r"[^A-Za-z0-9._-]", "_", f"{self.provider}__{self.model}")
        return safe

    @classmethod
    def from_dict(cls, role: int, d: dict[str, Any]) -> "RoleEndpoint":
        return cls(role=role, provider=d.get("provider", "vllm"), model=d["model"],
                   base_url=d["base_url"].rstrip("/"), api_key_env=d.get("api_key_env", "VLLM_API_KEY"),
                   limits=Limits.from_dict(d.get("limits")), open_weights=bool(d.get("open_weights", False)),
                   hf_repo=d.get("hf_repo"), hf_revision=d.get("hf_revision"),
                   extra_body=dict(d.get("extra_body", {})), max_tokens=int(d.get("max_tokens", 20)),
                   timeout_s=float(d.get("timeout_s", 120.0)))


class ChatBackend:
    """OpenAI-compatible chat backend with a free-tier governor.

    ``mode`` is "live" or "synthetic".  Synthetic mode never touches the network
    and is a pure function of (role, seed, presentation, matrix, pair) so the
    whole pipeline -- including the analysis and the pre-registered decision
    rules -- is exercised in CI at zero cost.
    """

    def __init__(self, pair_cfg: dict[str, Any], mode: str, workdir: Path,
                 require_open_weights: bool = True, synthetic_profile: dict[str, Any] | None = None) -> None:
        self.mode = mode
        self.pair_id = pair_cfg["pair_id"]
        self.label = pair_cfg.get("label", self.pair_id)
        self.capability_tier = pair_cfg.get("capability_tier", "unspecified")
        self.roles = [RoleEndpoint.from_dict(i, r) for i, r in enumerate(pair_cfg["roles"])]
        self.workdir = Path(workdir)
        self.synthetic_profile = synthetic_profile or pair_cfg.get("synthetic_profile", {})
        if mode == "live" and require_open_weights:
            closed = [r.model for r in self.roles if not r.open_weights]
            if closed:
                raise RuntimeError(
                    "P10 requires open-weight models so a reviewer can re-serve the exact "
                    f"revision offline; these are marked closed: {closed}")
            placeholder = ("PIN_", "REPLACE", "TODO", "XXX")
            unpinned = [r.model for r in self.roles
                        if not (r.hf_repo and r.hf_revision)
                        or any(p in str(r.hf_revision).upper() for p in placeholder)
                        or len(str(r.hf_revision)) < 8]
            if unpinned:
                raise RuntimeError(
                    "P10 requires a real hf_repo + hf_revision commit hash (not a placeholder) for: "
                    f"{unpinned}. Resolve it once with `huggingface-cli`/the HF API and paste it into "
                    "the protocol before spending any quota -- this is what lets a reviewer re-serve "
                    "the identical weights offline.")
        ledger_dir = self.workdir / "_usage"
        self.governors = {r.key: Governor(r.key, r.limits, ledger_dir) for r in self.roles}
        self._log_lock = threading.Lock()
        self.stats: dict[str, Any] = {"calls": 0, "retries": 0, "parse_failures": 0, "http_errors": 0}

    # -- provenance -------------------------------------------------------
    def provenance(self) -> dict[str, Any]:
        return {
            "pair_id": self.pair_id, "label": self.label, "capability_tier": self.capability_tier,
            "roles": [{"role": r.role, "provider": r.provider, "model": r.model, "base_url": r.base_url,
                       "open_weights": r.open_weights, "hf_repo": r.hf_repo, "hf_revision": r.hf_revision,
                       "limits": {"rpm": r.limits.rpm, "tpm": r.limits.tpm, "rpd": r.limits.rpd,
                                  "tpd": r.limits.tpd},
                       "extra_body": r.extra_body, "max_tokens": r.max_tokens} for r in self.roles],
        }

    def _log(self, role: RoleEndpoint, record: dict[str, Any]) -> None:
        path = self.workdir / "_raw" / f"{self.pair_id}__role{role.role}__{role.key}.jsonl"
        with self._log_lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, sort_keys=True) + "\n")

    # -- the call ---------------------------------------------------------
    def choose(self, role: int, messages: list[dict[str, str]], seed: int, context: dict[str, Any]) -> dict[str, Any]:
        """Return ``{action, raw, parse_ok, ...}``; never raises on a parse failure.

        A parse failure is *data*: the step is recorded with ``action=None`` and
        the runner marks the cell degraded rather than inventing an action.
        """
        if self.mode == "synthetic":
            return self._synthetic(role, seed, context)
        ep = self.roles[role]
        gov = self.governors[ep.key]
        est = sum(len(m["content"]) for m in messages) // 4 + ep.max_tokens + 16
        gov.acquire(est)
        used = est
        try:
            body: dict[str, Any] = {"model": ep.model, "messages": messages, "temperature": 0.7,
                                    "top_p": 0.9, "max_tokens": ep.max_tokens, "seed": int(seed)}
            body.update(ep.extra_body)
            key = os.environ.get(ep.api_key_env, "")
            last_err: Exception | None = None
            for attempt in range(5):
                try:
                    req = urlrequest.Request(
                        ep.base_url + "/chat/completions", data=json.dumps(body).encode(), method="POST",
                        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
                    with urlrequest.urlopen(req, timeout=ep.timeout_s) as resp:
                        headers = {k.lower(): v for k, v in resp.headers.items()}
                        data = json.loads(resp.read().decode())
                    text = (data.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""
                    usage = data.get("usage") or {}
                    used = int(usage.get("total_tokens", est) or est)
                    record = {"pair": self.pair_id, "role": role, "seed": int(seed),
                              "context": context, "response_id": data.get("id"),
                              "model_echo": data.get("model"),
                              "system_fingerprint": data.get("system_fingerprint"),
                              "usage": usage, "text": text,
                              "provider_headers": {k: v for k, v in headers.items()
                                                   if k.startswith(("x-ratelimit", "x-request", "x-groq", "cf-ray"))},
                              "attempt": attempt, "ts": datetime.now(timezone.utc).isoformat()}
                    try:
                        action = parse_action(text)
                        record["action"] = action
                        record["parse_ok"] = True
                        self._log(ep, record)
                        self.stats["calls"] += 1
                        return {"action": action, "raw": text, "parse_ok": True,
                                "model_echo": data.get("model"), "system_fingerprint": data.get("system_fingerprint")}
                    except UnparseableResponse as exc:
                        record["parse_ok"] = False
                        record["parse_error"] = exc.reason
                        self._log(ep, record)
                        self.stats["calls"] += 1
                        self.stats["parse_failures"] += 1
                        return {"action": None, "raw": text, "parse_ok": False, "parse_error": exc.reason,
                                "model_echo": data.get("model"), "system_fingerprint": data.get("system_fingerprint")}
                except urlerror.HTTPError as exc:  # 429 / 5xx
                    last_err = exc
                    self.stats["http_errors"] += 1
                    retry_after = exc.headers.get("Retry-After") if exc.headers else None
                    delay = float(retry_after) if retry_after and str(retry_after).replace(".", "").isdigit() \
                        else min(60.0, (2 ** attempt) + random.random())
                    if exc.code in (400, 401, 403, 404):
                        raise
                    self.stats["retries"] += 1
                    time.sleep(delay)
                except (urlerror.URLError, TimeoutError, json.JSONDecodeError) as exc:
                    last_err = exc
                    self.stats["retries"] += 1
                    time.sleep(min(30.0, (2 ** attempt) + random.random()))
            raise RuntimeError(f"exhausted retries for {ep.model}: {last_err}")
        finally:
            gov.release(used)

    # -- synthetic --------------------------------------------------------
    def _synthetic(self, role: int, seed: int, context: dict[str, Any]) -> dict[str, Any]:
        """Deterministic stand-in with a *configurable* compliance profile.

        The profile is what makes CI meaningful: by setting different per-arm
        compliance rates per pair we can check that the analysis recovers the
        planted presentation effect / registry effect and that the decision rules
        fire in the direction the pre-registration says they should.
        """
        prof = self.synthetic_profile
        arm = context.get("presentation", "NoAlign")
        base = float(prof.get("compliance", {}).get(arm, {"NoAlign": .20, "Advisory": .55, "RoleBound": .85}.get(arm, .5)))
        base += float(prof.get("registry_bonus", {}).get(context.get("registry", ""), 0.0))
        base = min(max(base, 0.0), 1.0)
        rng = np.random.default_rng(abs(hash((self.pair_id, role, int(seed), arm,
                                              context.get("matrix_id", ""), context.get("registry", "")))) % (2**32))
        if rng.random() < float(prof.get("parse_failure_rate", 0.0)):
            return {"action": None, "raw": "", "parse_ok": False, "parse_error": "synthetic_parse_failure"}
        target_action = int(context["target"][role])
        act = target_action if rng.random() < base else int(rng.integers(0, 2))
        return {"action": act, "raw": f"ACTION: {'AB'[act]}", "parse_ok": True,
                "model_echo": f"synthetic::{self.pair_id}", "system_fingerprint": "synthetic"}


__all__ = ["ChatBackend", "RoleEndpoint", "Limits", "Governor", "Ledger",
           "parse_action", "strip_reasoning", "RateLimitExhausted", "UnparseableResponse"]
