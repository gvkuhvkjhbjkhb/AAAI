"""A sealed, post-P5 registry for the confirmatory action-aware gate test.

Family labels are audit metadata only.  Prompts and controllers receive only the
payoff table.  P6 deliberately adds a role-asymmetric *safe* family and a
role-asymmetric *tradeoff* family: an action-aware certificate should accept
the former and reject the latter without consulting either label.
"""
from __future__ import annotations

from typing import Any
import numpy as np

from common import sha256_value
from matrix_registry import MatrixSpec


FAMILIES = ("anti_safe", "anti_tradeoff", "coordination", "mixed")


def _pair(a: float, b: float) -> tuple[float, float]:
    return (round(float(a), 2), round(float(b), 2))


def _j(rng: np.random.Generator, scale: float) -> float:
    return float(rng.uniform(-scale, scale))


def _matrix(family: str, rng: np.random.Generator):
    # In anti_safe, the target off-diagonal is a strict pure equilibrium and
    # Pareto-improves on the low diagonal basin.  In anti_tradeoff it is also
    # a strict equilibrium, but it gives Row less than its warm-up baseline.
    if family == "anti_safe":
        target = (_pair(4.35 + _j(rng, .18), 4.05 + _j(rng, .18)))
        return ((_pair(.45 + _j(rng, .12), .40 + _j(rng, .12)), target),
                (_pair(1.30 + _j(rng, .18), 1.25 + _j(rng, .18)), _pair(.20 + _j(rng, .10), .25 + _j(rng, .10))))
    if family == "anti_tradeoff":
        # (A,B) has high team reward but cannot meet row's non-inferiority
        # requirement.  It remains a pure equilibrium, so rejection cannot be
        # attributed merely to a coordination-risk heuristic.
        target = (_pair(.00 + _j(rng, .04), 5.00 + _j(rng, .08)))
        return ((_pair(.92 + _j(rng, .10), .92 + _j(rng, .10)), target),
                (_pair(.18 + _j(rng, .07), .20 + _j(rng, .07)), _pair(-.12 + _j(rng, .04), -.10 + _j(rng, .04))))
    if family == "coordination":
        return ((_pair(4.25 + _j(rng, .20), 4.10 + _j(rng, .20)), _pair(.15 + _j(rng, .10), .95 + _j(rng, .12))),
                (_pair(.95 + _j(rng, .12), .15 + _j(rng, .10)), _pair(3.20 + _j(rng, .20), 3.05 + _j(rng, .20))))
    if family == "mixed":
        base = 2.15 + _j(rng, .12)
        return tuple(tuple(_pair(base + _j(rng, .16), base + _j(rng, .16)) for _ in range(2)) for _ in range(2))
    raise ValueError(f"Unknown P6 family {family}")


def build_p6_registry(seed: int, n_per_family: int) -> list[MatrixSpec]:
    if n_per_family < 1:
        raise ValueError("n_per_family must be positive")
    rng = np.random.default_rng(seed)
    return [MatrixSpec(f"p6_{family}_{i:02d}", family, _matrix(family, rng))
            for family in FAMILIES for i in range(1, n_per_family + 1)]


def registry_audit(registry: list[MatrixSpec]) -> list[dict[str, Any]]:
    return [x.audit_dict() for x in registry]


def registry_sha256(registry: list[MatrixSpec]) -> str:
    return sha256_value(registry_audit(registry))
