"""Action-aligned feasibility certificate for role-specific recommendations.

This is not a certificate that the advisory will be followed.  It certifies
only that the *recommended joint action* is individually non-inferior to the
observed NoAlign baseline, is team non-inferior, and has no profitable
unilateral deviation in the known payoff table.  The frozen P4 predictive LCB
continues to certify the expected effect of actually issuing the advisory.
"""
from __future__ import annotations

from typing import Any, Iterable
import numpy as np

from matrix_registry import MatrixSpec, recommended_joint_action


def _upper_mean(samples: np.ndarray, draws: int, confidence: float, rng: np.random.Generator) -> float:
    values = rng.choice(samples, size=(draws, len(samples)), replace=True).mean(axis=1)
    return float(np.quantile(values, confidence))


def summarize_action_safety(steps: Iterable[dict[str, Any]], spec: MatrixSpec, cfg: dict[str, Any], bootstrap_seed: int) -> dict[str, Any]:
    obs = list(steps)
    if not obs:
        raise ValueError("warm-up must contain observations")
    target = recommended_joint_action(spec)
    target_rewards = np.asarray(spec.payoff_matrix[target[0]][target[1]], dtype=float)
    rewards = np.asarray([x["rewards"] for x in obs], dtype=float)
    team_samples = rewards.mean(axis=1)
    rng = np.random.default_rng(bootstrap_seed)
    draws, confidence = int(cfg["bootstrap_samples"]), float(cfg["confidence"])
    upper_roles = [_upper_mean(rewards[:, role], draws, confidence, rng) for role in range(2)]
    upper_team = _upper_mean(team_samples, draws, confidence, rng)
    role_lcb = [float(target_rewards[i] - upper_roles[i]) for i in range(2)]
    team_lcb = float(target_rewards.mean() - upper_team)
    deviation_gains = []
    for role in range(2):
        other_action = target[1 - role]
        if role == 0:
            alternatives = [float(spec.payoff_matrix[own][other_action][0]) for own in range(2)]
        else:
            alternatives = [float(spec.payoff_matrix[other_action][own][1]) for own in range(2)]
        deviation_gains.append(float(max(alternatives) - target_rewards[role]))
    profiles = {tuple(int(a) for a in x["actions"]) for x in obs}
    reasons: list[str] = []
    if len(obs) < int(cfg["min_total_observations"]): reasons.append("insufficient_total_observations")
    if len(profiles) / 4.0 < float(cfg["min_profile_coverage"]): reasons.append("insufficient_profile_coverage")
    if team_lcb < -float(cfg["team_noninferiority_margin"]): reasons.append("team_noninferior_not_certified")
    if min(role_lcb) < -float(cfg["role_noninferiority_margin"]): reasons.append("role_noninferior_not_certified")
    if min(target_rewards) < float(cfg["minimum_role_target_reward"]): reasons.append("minimum_role_reward_not_certified")
    if max(deviation_gains) > float(cfg["max_unilateral_deviation_gain"]) + 1e-9: reasons.append("target_not_individually_stable")
    return {
        "certificate_type": "action_aligned_feasibility_v1", "recommended_joint_action": list(target),
        "target_rewards": target_rewards.tolist(), "n_observations": len(obs),
        "n_unique_profiles": len(profiles), "profile_coverage": len(profiles) / 4.0,
        "baseline_role_upper_means": upper_roles, "baseline_team_upper_mean": upper_team,
        "role_noninferiority_lcb": role_lcb, "team_noninferiority_lcb": team_lcb,
        "minimum_role_target_reward": float(cfg["minimum_role_target_reward"]),
        "unilateral_deviation_gains": deviation_gains, "safety_pass": not reasons,
        "safety_reasons": reasons,
    }
