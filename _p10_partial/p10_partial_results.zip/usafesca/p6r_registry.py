"""Independent small P6R registry; its payoff draws never reuse P6's seed."""
from __future__ import annotations
from matrix_registry import MatrixSpec
from p6_registry import build_p6_registry, registry_audit, registry_sha256


def build_p6r_registry(seed: int, n_per_family: int) -> list[MatrixSpec]:
    source = build_p6_registry(seed, n_per_family)
    return [MatrixSpec(x.matrix_id.replace("p6_", "p6r_", 1), x.analysis_family, x.payoff_matrix) for x in source]


__all__ = ["build_p6r_registry", "registry_audit", "registry_sha256"]
